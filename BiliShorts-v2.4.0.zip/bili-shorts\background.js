/* B站竖刷 BiliShorts — 后台 Service Worker
 * 代理 B 站 API 请求（绕过页面 CORS、自动携带登录 Cookie），
 * 实现 WBI 签名（1080P+ 画质与弹幕接口需要），
 * 处理 Alt+V 快捷键。
 * type=api  : JSON 接口（msg.wbi=true 时自动 WBI 签名）
 * type=raw  : 文本接口（弹幕 XML，自动 zlib 解压，可 WBI 签名） */

'use strict';

const API_RE = /^https:\/\/(api\.bilibili\.com)\//i;

/* ---------------- MD5（RFC 1321，用于 WBI 签名） ---------------- */

function md5(str) {
  function toUtf8(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c < 128) out.push(c);
      else if (c < 2048) out.push(192 | (c >> 6), 128 | (c & 63));
      else if (c >= 0xd800 && c < 0xdc00 && i + 1 < s.length) {
        const c2 = s.charCodeAt(i + 1);
        const cp = 0x10000 + ((c & 0x3ff) << 10) + (c2 & 0x3ff);
        out.push(240 | (cp >> 18), 128 | ((cp >> 12) & 63), 128 | ((cp >> 6) & 63), 128 | (cp & 63));
        i++;
      } else out.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
    }
    return out;
  }
  function rl(v, c) { return (v << c) | (v >>> (32 - c)); }
  function add(a, b) {
    const l = (a & 0xffff) + (b & 0xffff);
    const h = (a >> 16) + (b >> 16) + (l >> 16);
    return (h << 16) | (l & 0xffff);
  }
  const K = [];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296);
  const S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
    5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
  const msg = toUtf8(String(str));
  const bitLen = msg.length * 8;
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  for (let i = 0; i < 8; i++) msg.push(Math.floor(bitLen / Math.pow(2, 8 * i)) & 255);
  let a0 = 1732584193, b0 = -271733879, c0 = -1732584194, d0 = 271733878;
  for (let off = 0; off < msg.length; off += 64) {
    const M = [];
    for (let j = 0; j < 16; j++) {
      M[j] = msg[off + j * 4] | (msg[off + j * 4 + 1] << 8) | (msg[off + j * 4 + 2] << 16) | (msg[off + j * 4 + 3] << 24);
    }
    let A = a0, B = b0, C = c0, D = d0;
    for (let k = 0; k < 64; k++) {
      let F, g;
      if (k < 16) { F = (B & C) | (~B & D); g = k; }
      else if (k < 32) { F = (D & B) | (~D & C); g = (5 * k + 1) % 16; }
      else if (k < 48) { F = B ^ C ^ D; g = (3 * k + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * k) % 16; }
      F = add(A, add(F, add(M[g], K[k])));
      A = D; D = C; C = B;
      B = add(B, rl(F, S[k]));
    }
    a0 = add(a0, A); b0 = add(b0, B); c0 = add(c0, C); d0 = add(d0, D);
  }
  function hx(n) {
    let s = '';
    for (let j = 0; j < 4; j++) s += ((n >> (j * 8)) & 255).toString(16).padStart(2, '0');
    return s;
  }
  return hx(a0) + hx(b0) + hx(c0) + hx(d0);
}

/* ---------------- WBI 签名 ---------------- */

const WBI_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
  27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
  37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
  22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52];

let wbiCache = { key: '', time: 0 };

async function getMixinKey() {
  if (wbiCache.key && Date.now() - wbiCache.time < 3600000) return wbiCache.key;
  const res = await fetch('https://api.bilibili.com/x/web-interface/nav', { credentials: 'include' });
  const j = await res.json();
  const img = (j.data && j.data.wbi_img) || {};
  const base = (u) => {
    const s = String(u || '').split('/').pop() || '';
    return s.split('.')[0];
  };
  const raw = base(img.img_url) + base(img.sub_url);
  if (raw.length < 32) throw new Error('wbi key 获取失败');
  wbiCache.key = WBI_TAB.map((i) => raw[i]).join('').slice(0, 32);
  wbiCache.time = Date.now();
  return wbiCache.key;
}

async function wbiSign(url) {
  const mixinKey = await getMixinKey();
  const u = new URL(url);
  const params = {};
  u.searchParams.forEach((v, k) => { params[k] = v; });
  params.wts = Math.floor(Date.now() / 1000);
  const keys = Object.keys(params).sort();
  const query = keys.map((k) => {
    const v = String(params[k]).replace(/[!'()*]/g, '');
    return encodeURIComponent(k) + '=' + encodeURIComponent(v);
  }).join('&');
  const wRid = md5(query + mixinKey);
  return u.origin + u.pathname + '?' + query + '&w_rid=' + wRid;
}

/* ---------------- 消息处理 ---------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'api' || msg.type === 'raw') {
    (msg.type === 'api' ? handleApi(msg) : handleRaw(msg))
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true; // 异步响应
  }
  if (msg.type === 'wbisign') {
    // 只返回签名后的 URL，由页面自己发起请求（Referer/Origin 为B站页面，避免风控 412）
    wbiSign(String(msg.url || ''))
      .then((signed) => sendResponse({ ok: true, data: { url: signed } }))
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true;
  }
});

async function handleApi(msg) {
  let url = String(msg.url || '');
  if (!API_RE.test(url)) throw new Error('不允许的请求地址');
  if (msg.wbi) url = await wbiSign(url);
  const init = {
    method: msg.method === 'POST' ? 'POST' : 'GET',
    credentials: 'include',
    headers: {}
  };
  if (init.method === 'POST') {
    init.body = String(msg.body || '');
    init.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
  }
  const res = await fetch(url, init);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error('接口返回异常（HTTP ' + res.status + '）');
  }
}

async function handleRaw(msg) {
  let url = String(msg.url || '');
  if (!API_RE.test(url)) throw new Error('不允许的请求地址');
  if (msg.wbi) url = await wbiSign(url);
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const buf = await res.arrayBuffer();
  const u8 = new Uint8Array(buf);
  // 弹幕 list.so 返回 zlib(deflate) 压缩的 XML；0x78 是 zlib 头
  if (u8.length > 2 && u8[0] === 0x78 && typeof DecompressionStream !== 'undefined') {
    const stream = new Blob([buf]).stream().pipeThrough(new DecompressionStream('deflate'));
    return { text: await new Response(stream).text() };
  }
  return { text: new TextDecoder('utf-8').decode(buf) };
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-shorts') return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id != null) await chrome.tabs.sendMessage(tab.id, { type: 'toggle' });
  } catch (e) {
    /* 页面没有内容脚本（非B站视频页），忽略 */
  }
});
