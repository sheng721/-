/* ============================================================
 * B站竖刷 BiliShorts v2 — content script
 * 沉浸式竖屏刷视频：
 *  - DASH + MSE 播放（登录后可解锁 1080P/1080P60/4K，接口可用时）
 *  - 弹幕渲染（拉取官方弹幕池，canvas 绘制，B 键开关）
 *  - 滚轮 / ↑↓ 方向键切换视频，清晰度菜单即时切换
 *  - DASH 失败自动回退 platform=html5 直连 MP4（最高720P）
 * ============================================================ */
(() => {
  'use strict';
  if (window.__BILI_SHORTS_LOADED__) return;
  window.__BILI_SHORTS_LOADED__ = true;

  /* ---------------- 常量 ---------------- */

  const DEFAULTS = { dashQn: 'max', danmakuOn: true, fill: 'contain', autoNext: true };
  const QUALITY_LABEL = {
    6: '240P', 16: '360P', 32: '480P', 64: '720P', 74: '720P60',
    80: '1080P', 112: '1080P+', 116: '1080P60', 120: '4K', 125: 'HDR', 126: '杜比视界'
  };

  const ICON = {
    heart: '<svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
    coin: '<svg viewBox="0 0 24 24"><circle cx="9" cy="9" r="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="15" cy="15" r="5" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
    share: '<svg viewBox="0 0 24 24"><path d="M14 9V5l7 7-7 7v-4.1c-5 0-8.5 1.6-11 5.1 1-5 4-10 11-11z"/></svg>',
    open: '<svg viewBox="0 0 24 24"><path d="M19 19H5V5h6V3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-6h-2v6zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
    volume: '<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05A4.5 4.5 0 0016.5 12zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>',
    mute: '<svg viewBox="0 0 24 24"><path d="M16.5 12A4.5 4.5 0 0014 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0021 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 003.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>',
    fs: '<svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>',
    fit: '<svg viewBox="0 0 24 24"><path d="M5 5h5v2H7v3H5V5zm9 0h5v5h-2V7h-3V5zM5 14h2v3h3v2H5v-5zm12 0h2v5h-5v-2h3v-3z"/></svg>',
    star: '<svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>',
    bubble: '<svg viewBox="0 0 24 24"><path d="M20 2H4a2 2 0 00-2 2v18l4-4h14a2 2 0 002-2V4a2 2 0 00-2-2z"/></svg>'
  };

  const CSS_TEXT = `
.root{position:absolute;inset:0;background:#000;color:#fff;overflow:hidden;
  font-family:"PingFang SC","Microsoft YaHei",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  font-size:14px;user-select:none;opacity:0;transition:opacity .25s ease;}
.root.on{opacity:1;}
*{box-sizing:border-box;margin:0;padding:0;}
.viewport{position:absolute;inset:0;overflow:hidden;}
.slide{position:absolute;inset:0;background:#000;transform:translateY(100%);
  transition:transform .38s cubic-bezier(.22,.61,.36,1);will-change:transform;}
.slide.above{transform:translateY(-100%);}
.slide.active{transform:translateY(0);}
video.player{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000;}
.dm-canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:3;}
.shade{position:absolute;inset:0;pointer-events:none;z-index:2;
  background:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0) 16%),
             linear-gradient(to top,rgba(0,0,0,.72),rgba(0,0,0,0) 36%);}
.topbar{position:absolute;top:0;left:0;right:0;height:52px;display:flex;align-items:center;
  justify-content:space-between;padding:0 16px;z-index:5;}
.brand{display:flex;align-items:center;gap:8px;font-weight:600;font-size:15px;
  text-shadow:0 1px 3px rgba(0,0,0,.6);}
.brand .dot{width:10px;height:10px;border-radius:50%;background:#fb7299;
  box-shadow:0 0 8px rgba(251,114,153,.9);}
.top-actions{display:flex;gap:6px;align-items:center;}
.icon-btn{height:34px;min-width:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;
  background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.14);color:#fff;cursor:pointer;
  font-size:12px;font-weight:600;padding:0 9px;font-family:inherit;}
.icon-btn:hover{background:rgba(255,255,255,.22);}
.icon-btn svg{width:18px;height:18px;fill:currentColor;}
.icon-btn.off{opacity:.45;}
.icon-btn .i-mut{display:none;}
.icon-btn.muted .i-vol{display:none;}
.icon-btn.muted .i-mut{display:contents;}
.i-vol,.i-mut{display:contents;}
.qmenu{position:absolute;top:58px;right:16px;z-index:8;background:rgba(18,18,22,.96);
  border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:6px;min-width:150px;
  box-shadow:0 8px 28px rgba(0,0,0,.5);}
.qmenu[hidden]{display:none;}
.qmenu .qmi{display:flex;justify-content:space-between;gap:14px;align-items:center;padding:8px 12px;
  border-radius:8px;cursor:pointer;font-size:13px;color:#ddd;}
.qmenu .qmi:hover{background:rgba(255,255,255,.1);}
.qmenu .qmi.cur{color:#fb7299;font-weight:600;}
.qmenu .qmi .vip{font-size:10px;color:#ffb027;border:1px solid #ffb027;border-radius:4px;padding:0 3px;}
.info{position:absolute;left:22px;bottom:72px;right:130px;z-index:4;}
.owner{display:flex;align-items:center;gap:10px;margin-bottom:8px;cursor:pointer;width:fit-content;}
.avatar{width:38px;height:38px;border-radius:50%;border:2px solid rgba(255,255,255,.85);
  object-fit:cover;background:#222;}
.owner-name{font-weight:600;font-size:14px;text-shadow:0 1px 3px rgba(0,0,0,.7);}
.title{font-size:15px;line-height:1.45;margin-bottom:6px;cursor:pointer;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
  text-shadow:0 1px 3px rgba(0,0,0,.7);}
.meta{font-size:12px;color:rgba(255,255,255,.78);display:flex;gap:6px;align-items:center;
  flex-wrap:wrap;text-shadow:0 1px 3px rgba(0,0,0,.7);}
.meta .q{color:#ffd04d;font-weight:600;}
.rail{position:absolute;right:20px;bottom:72px;z-index:4;display:flex;flex-direction:column;
  gap:16px;align-items:center;}
.rail-item{display:flex;flex-direction:column;align-items:center;gap:4px;}
.rail-btn{width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,.4);
  border:1px solid rgba(255,255,255,.18);color:#fff;display:flex;align-items:center;
  justify-content:center;cursor:pointer;transition:background .15s,transform .15s;}
.rail-btn:hover{background:rgba(255,255,255,.26);transform:scale(1.06);}
.rail-btn.on{background:#fb7299;border-color:#fb7299;}
.rail-btn.on:hover{background:#fc8ba9;}
.rail-btn svg{width:20px;height:20px;fill:currentColor;}
.rail-count{font-size:12px;color:rgba(255,255,255,.88);text-shadow:0 1px 3px rgba(0,0,0,.7);}
.bottombar{position:absolute;left:0;right:0;bottom:0;height:48px;display:flex;align-items:center;
  gap:12px;padding:0 16px;z-index:5;}
.time{font-size:12px;color:rgba(255,255,255,.85);font-variant-numeric:tabular-nums;
  min-width:40px;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,.7);}
.progress{flex:1;height:16px;display:flex;align-items:center;cursor:pointer;touch-action:none;}
.progress .trackbg{position:relative;width:100%;height:3px;border-radius:2px;
  background:rgba(255,255,255,.22);transition:height .12s;}
.progress:hover .trackbg{height:5px;}
.progress .buffered{position:absolute;left:0;top:0;bottom:0;width:0;
  background:rgba(255,255,255,.35);border-radius:2px;}
.progress .played{position:absolute;left:0;top:0;bottom:0;width:0;background:#fb7299;border-radius:2px;}
.progress .knob{position:absolute;top:50%;left:0;width:11px;height:11px;border-radius:50%;
  background:#fff;transform:translate(-50%,-50%);box-shadow:0 0 4px rgba(0,0,0,.5);}
.center-msg{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:14px;background:rgba(0,0,0,.6);z-index:6;text-align:center;
  padding:0 48px;}
.center-msg[hidden]{display:none;}
.msg-text{font-size:15px;line-height:1.7;text-shadow:0 1px 3px rgba(0,0,0,.8);}
.msg-actions{display:flex;gap:10px;}
.msg-actions button{background:#fb7299;border:none;color:#fff;padding:8px 18px;
  border-radius:18px;cursor:pointer;font-size:13px;}
.msg-actions button.ghost{background:rgba(255,255,255,.18);}
.spin{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
  z-index:6;pointer-events:none;}
.spin[hidden]{display:none;}
.spinner{width:36px;height:36px;border-radius:50%;border:3px solid rgba(255,255,255,.25);
  border-top-color:#fb7299;animation:bsspin 1s linear infinite;}
@keyframes bsspin{to{transform:rotate(360deg);}}
.toast{position:absolute;top:64px;left:50%;transform:translateX(-50%);
  background:rgba(20,20,20,.88);border:1px solid rgba(255,255,255,.12);color:#fff;
  padding:9px 16px;border-radius:10px;font-size:13px;z-index:9;opacity:0;
  transition:opacity .25s,transform .25s;pointer-events:none;max-width:72%;text-align:center;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(4px);}
.cmt-panel{position:absolute;top:0;right:0;bottom:0;width:390px;max-width:88%;
  background:rgba(15,15,21,.95);border-left:1px solid rgba(255,255,255,.12);z-index:7;
  transform:translateX(103%);transition:transform .28s ease;display:flex;flex-direction:column;}
.cmt-panel.open{transform:translateX(0);}
.cmt-head{height:50px;display:flex;align-items:center;gap:8px;padding:0 14px;flex:none;
  border-bottom:1px solid rgba(255,255,255,.1);font-size:14px;font-weight:600;}
.cmt-head .cnt{color:#9a9aa3;font-size:12px;font-weight:400;}
.cmt-head .sp{flex:1;}
.cmt-close{background:none;border:none;color:#fff;font-size:18px;cursor:pointer;width:30px;height:30px;border-radius:6px;}
.cmt-close:hover{background:rgba(255,255,255,.12);}
.cmt-list{flex:1;overflow-y:auto;padding:8px 14px 20px;}
.cmt-item{display:flex;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06);}
.cmt-item img{width:32px;height:32px;border-radius:50%;flex:none;background:#222;object-fit:cover;}
.cmt-body{flex:1;min-width:0;}
.cmt-name{font-size:12px;color:#9a9aa3;margin-bottom:3px;}
.cmt-text{font-size:13px;line-height:1.55;word-break:break-word;}
.cmt-meta{font-size:11px;color:#77777f;margin-top:4px;display:flex;gap:10px;}
.cmt-more{text-align:center;padding:12px 0;color:#9a9aa3;font-size:12px;}
.cmt-tab{position:absolute;right:0;top:44%;z-index:7;background:rgba(16,16,22,.85);
  border:1px solid rgba(255,255,255,.14);border-right:none;color:#fff;padding:12px 9px;
  writing-mode:vertical-lr;letter-spacing:6px;font-size:12px;cursor:pointer;
  border-radius:8px 0 0 8px;}
.cmt-tab:hover{background:rgba(255,255,255,.16);}
`;

  /* ---------------- 状态 ---------------- */

  const state = {
    active: false,
    order: [],
    idx: -1,
    visited: new Set(),
    slides: new Map(),
    locked: false,
    extending: false,
    seedPage: 1,
    popularPage: 1,
    forceMuted: false
  };
  const prevState = { overflowBody: '', overflowHtml: '', title: '' };

  // 评论面板状态
  const cmt = { open: false, aid: 0, list: [], next: 0, count: 0, loading: false, eof: false, fails: 0 };
  let myMid = null;

  const dataCache = new Map();
  const dashCache = new Map(); // bvid|cid -> playurl(dash) 原始 data
  const urlCache = new Map();  // bvid|cid|qn -> {urls, quality}

  let host = null, shadow = null, ui = {};
  let seeking = false;
  let toastTimer = null;
  let lastWheelTime = 0, wheelArmed = true;
  let touchY = null, touchX = null;

  /* ---------------- 设置 ---------------- */

  let settings = Object.assign({}, DEFAULTS);
  try {
    chrome.storage.sync.get(DEFAULTS).then((s) => {
      Object.assign(settings, s);
      applySettings();
    }).catch(() => {});
    chrome.storage.onChanged.addListener((changes) => {
      for (const k of Object.keys(changes)) settings[k] = changes[k].newValue;
      applySettings();
    });
  } catch (e) { /* 扩展上下文失效 */ }

  function applySettings() {
    for (const slide of state.slides.values()) {
      slide.video.style.objectFit = settings.fill === 'cover' ? 'cover' : 'contain';
      if (slide.danmaku) slide.danmaku.setOn(!!settings.danmakuOn);
    }
    if (ui.dmBtn) ui.dmBtn.classList.toggle('off', !settings.danmakuOn);
    if (ui.muteBtn) syncMuteIcon();
  }

  /* ---------------- 工具 ---------------- */

  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
  function fmtCount(n) {
    n = Number(n) || 0;
    if (n >= 1e8) return (n / 1e8).toFixed(1) + '亿';
    if (n >= 1e4) return (n / 1e4).toFixed(1) + '万';
    return String(n);
  }
  function fmtTime(s) {
    s = Math.max(0, Math.floor(Number(s) || 0));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    const mm = h ? String(m).padStart(2, '0') : String(m);
    return (h ? h + ':' + mm : mm) + ':' + String(sec).padStart(2, '0');
  }
  function fmtDate(ts) {
    if (!ts) return '';
    const d = new Date(ts * 1000);
    const p = (x) => String(x).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function getCsrf() {
    const m = document.cookie.match(/(?:^|;\s*)bili_jct=([^;]+)/);
    return m ? m[1] : '';
  }
  function isLogged() { return !!getCsrf(); }
  function qlabel(q, formats) {
    if (formats && Array.isArray(formats)) {
      const f = formats.find((x) => x.quality === q);
      if (f) return (f.new_description || f.display_desc || '').replace(/^.*?\s/, (mm) => (mm.trim() === '高清' || mm.trim() === '流畅' ? '' : mm)) || QUALITY_LABEL[q] || q + 'P';
    }
    return QUALITY_LABEL[q] || (q ? q + 'P' : '');
  }
  function decodeEntities(s) {
    return String(s)
      .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
  }

  /* ---- 最小 protobuf 解析（弹幕 seg.so 用）：返回 {字段号: [varint 或 Uint8Array]} ---- */
  function parsePb(u8) {
    const out = {};
    let o = 0;
    while (o < u8.length) {
      let tag = 0, mult = 1, b;
      do {
        if (o >= u8.length) return out;
        b = u8[o++];
        tag += (b & 0x7f) * mult; mult *= 128;
      } while (b & 0x80);
      const fn = Math.floor(tag / 8);
      const wt = tag % 8;
      if (wt === 0) {
        let v = 0, m2 = 1;
        do {
          if (o >= u8.length) return out;
          b = u8[o++];
          v += (b & 0x7f) * m2; m2 *= 128;
        } while (b & 0x80);
        (out[fn] = out[fn] || []).push(v);
      } else if (wt === 2) {
        let len = 0, m2 = 1;
        do {
          if (o >= u8.length) return out;
          b = u8[o++];
          len += (b & 0x7f) * m2; m2 *= 128;
        } while (b & 0x80);
        if (o + len > u8.length) return out;
        (out[fn] = out[fn] || []).push(u8.slice(o, o + len));
        o += len;
      } else if (wt === 1) { o += 8; }
      else if (wt === 5) { o += 4; }
      else { return out; }
    }
    return out;
  }
  function parsePbElem(u8) {
    const out = { progress: 0, mode: 1, fontsize: 25, color: 0xffffff, text: '' };
    try {
      const f = parsePb(u8);
      if (f[2] && typeof f[2][0] === 'number') out.progress = f[2][0];
      if (f[3] && typeof f[3][0] === 'number') out.mode = f[3][0];
      if (f[4] && typeof f[4][0] === 'number') out.fontsize = f[4][0];
      if (f[5] && typeof f[5][0] === 'number') out.color = f[5][0];
      if (f[7] && typeof f[7] === 'object' && f[7].length != null) {
        out.text = new TextDecoder('utf-8').decode(f[7]);
      }
    } catch (e) { /* 单条解析失败跳过 */ }
    return out;
  }
  function shortErr(e) { return String((e && e.message) || e).slice(0, 60); }

  /* ---------------- 后台通道 ---------------- */

  function bgSend(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => {
          const err = chrome.runtime.lastError;
          if (err) return reject(new Error(err.message));
          if (!res) return reject(new Error('无响应'));
          if (!res.ok) return reject(new Error(res.error || '请求失败'));
          resolve(res);
        });
      } catch (e) {
        reject(new Error('扩展上下文已失效，请刷新页面后重试'));
      }
    });
  }
  async function bgApi(url, opts = {}) {
    const res = await bgSend({ type: 'api', url, method: opts.method || 'GET', body: opts.body || null, wbi: !!opts.wbi });
    return res.data;
  }
  async function bgText(url, opts = {}) {
    const res = await bgSend({ type: 'raw', url, wbi: !!opts.wbi });
    return res.text;
  }

  // 页面直连请求（Referer/Origin 为B站页面，写操作不会被风控 412）
  function getCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
    return m ? m[1] : '';
  }
  async function directGet(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  }
  async function directPost(url, params) {
    const res = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: new URLSearchParams(params).toString()
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  }
  // 后台签名 + 页面直连（需要 WBI 的 GET）
  async function wbiGet(url) {
    let signed = url;
    try {
      signed = await wbiSignC(url);
    } catch (e) {
      try { const res = await bgSend({ type: 'wbisign', url }); if (res && res.data && res.data.url) signed = res.data.url; } catch (e2) { }
    }
    return await directGet(signed);
  }

  /* ---- 页面侧 WBI 签名（不依赖后台通信） ---- */
  const WBI_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52];
  let wbiC = { key: '', time: 0 };
  function md5c(str) {
    function toUtf8(s) {
      const out = [];
      for (let i = 0; i < s.length; i++) {
        const c = s.charCodeAt(i);
        if (c < 128) out.push(c);
        else if (c < 2048) out.push(192 | (c >> 6), 128 | (c & 63));
        else if (c >= 0xd800 && c < 0xdc00 && i + 1 < s.length) {
          const c2 = s.charCodeAt(i + 1);
          const cp = 0x10000 + ((c & 0x3ff) << 10) + (c2 & 0x3ff);
          out.push(240 | (cp >> 18), 128 | ((cp >> 12) & 63), 128 | ((cp >> 6) & 63), 128 | (cp & 63));
          i++;
        } else out.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
      }
      return out;
    }
    function rl(v, c) { return (v << c) | (v >>> (32 - c)); }
    function add(a, b) {
      const l = (a & 0xffff) + (b & 0xffff);
      const h = (a >> 16) + (b >> 16) + (l >> 16);
      return (h << 16) | (l & 0xffff);
    }
    const K = [];
    for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296);
    const S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
      5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
      4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
      6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const msg = toUtf8(String(str));
    const bitLen = msg.length * 8;
    msg.push(0x80);
    while (msg.length % 64 !== 56) msg.push(0);
    for (let i = 0; i < 8; i++) msg.push(Math.floor(bitLen / Math.pow(2, 8 * i)) & 255);
    let a0 = 1732584193, b0 = -271733879, c0 = -1732584194, d0 = 271733878;
    for (let off = 0; off < msg.length; off += 64) {
      const M = [];
      for (let j = 0; j < 16; j++) {
        M[j] = msg[off + j * 4] | (msg[off + j * 4 + 1] << 8) | (msg[off + j * 4 + 2] << 16) | (msg[off + j * 4 + 3] << 24);
      }
      let A = a0, B = b0, C = c0, D = d0;
      for (let k = 0; k < 64; k++) {
        let F, g;
        if (k < 16) { F = (B & C) | (~B & D); g = k; }
        else if (k < 32) { F = (D & B) | (~D & C); g = (5 * k + 1) % 16; }
        else if (k < 48) { F = B ^ C ^ D; g = (3 * k + 5) % 16; }
        else { F = C ^ (B | ~D); g = (7 * k) % 16; }
        F = add(A, add(F, add(M[g], K[k])));
        A = D; D = C; C = B;
        B = add(B, rl(F, S[k]));
      }
      a0 = add(a0, A); b0 = add(b0, B); c0 = add(c0, C); d0 = add(d0, D);
    }
    function hx(n) {
      let s = '';
      for (let j = 0; j < 4; j++) s += ((n >> (j * 8)) & 255).toString(16).padStart(2, '0');
      return s;
    }
    return hx(a0) + hx(b0) + hx(c0) + hx(d0);
  }
  async function getMixinKeyC() {
    if (wbiC.key && Date.now() - wbiC.time < 3600000) return wbiC.key;
    const j = await directGet('https://api.bilibili.com/x/web-interface/nav');
    const img = (j.data && j.data.wbi_img) || {};
    const base = (u) => {
      const s = String(u || '').split('/').pop() || '';
      return s.split('.')[0];
    };
    const raw = base(img.img_url) + base(img.sub_url);
    if (raw.length < 32) throw new Error('wbi key 获取失败');
    wbiC.key = WBI_TAB.map((i) => raw[i]).join('').slice(0, 32);
    wbiC.time = Date.now();
    return wbiC.key;
  }
  async function wbiSignC(url) {
    const key = await getMixinKeyC();
    const u = new URL(url);
    const params = {};
    u.searchParams.forEach((v, k) => { params[k] = v; });
    params.wts = Math.floor(Date.now() / 1000);
    const keys = Object.keys(params).sort();
    const query = keys.map((k) => {
      const v = String(params[k]).replace(/[!'()*]/g, '');
      return encodeURIComponent(k) + '=' + encodeURIComponent(v);
    }).join('&');
    return u.origin + u.pathname + '?' + query + '&w_rid=' + md5c(query + key);
  }

  /* ---------------- B站 API ---------------- */

  async function getView(bvid) {
    if (dataCache.has(bvid)) return dataCache.get(bvid);
    const j = await bgApi('https://api.bilibili.com/x/web-interface/view?bvid=' + encodeURIComponent(bvid));
    if (j.code !== 0 || !j.data) throw new Error(j.message || '获取视频信息失败');
    dataCache.set(bvid, j.data);
    return j.data;
  }

  // DASH（WBI 签名端点，登录可解锁 1080P+/4K；失败回退老接口，再回退 html5 MP4）
  async function getPlayDash(bvid, cid) {
    const key = bvid + '|' + cid;
    if (dashCache.has(key)) return dashCache.get(key);
    const q = 'bvid=' + encodeURIComponent(bvid) + '&cid=' + cid + '&qn=0&fnval=16&fnver=0&fourk=1';
    let j = null;
    // WBI 签名端点优先（高画质），偶发限流重试一次
    for (let t = 0; t < 2; t++) {
      try {
        j = await bgApi('https://api.bilibili.com/x/player/wbi/playurl?' + q, { wbi: true });
        if (j.code === 0 && j.data && j.data.dash) break;
      } catch (e) {
        j = null;
      }
      await sleep(500);
    }
    if (!j || j.code !== 0 || !j.data || !j.data.dash) {
      // 老接口回退（可能限 720P）
      try {
        j = await bgApi('https://api.bilibili.com/x/player/playurl?' + q);
      } catch (e) {
        j = null;
      }
      if (!j || j.code !== 0 || !j.data || !j.data.dash) throw new Error((j && j.message) || '获取播放地址失败');
    }
    dashCache.set(key, j.data);
    return j.data;
  }

  async function getPlayMp4(bvid, cid) {
    const wantQn = settings.dashQn === 'max' ? 64 : Math.min(64, Number(settings.dashQn) || 64);
    const key = bvid + '|' + cid + '|' + wantQn;
    if (urlCache.has(key)) return urlCache.get(key);
    const q = 'bvid=' + encodeURIComponent(bvid) + '&cid=' + cid + '&qn=' + wantQn + '&fnval=0&fnver=0&platform=html5&high_quality=' + (wantQn >= 64 ? 1 : 0);
    let j = null;
    try {
      j = await bgApi('https://api.bilibili.com/x/player/wbi/playurl?' + q, { wbi: true });
    } catch (e) { j = null; }
    if (!j || j.code !== 0 || !j.data || !Array.isArray(j.data.durl) || !j.data.durl.length) {
      j = await bgApi('https://api.bilibili.com/x/player/playurl?' + q);
    }
    if (j.code !== 0 || !j.data || !Array.isArray(j.data.durl) || !j.data.durl.length) {
      throw new Error(j.message || '获取播放地址失败');
    }
    const urls = [];
    for (const d of j.data.durl) {
      if (d.url) urls.push(d.url.replace(/^http:/, 'https:'));
      if (d.backup_url) for (const u of d.backup_url) if (u) urls.push(u.replace(/^http:/, 'https:'));
    }
    const v = { urls, quality: j.data.quality || 0 };
    urlCache.set(key, v);
    return v;
  }

  function pushCandidates(list) {
    let added = 0;
    for (const it of list || []) {
      const bvid = it && it.bvid;
      if (!bvid || state.visited.has(bvid)) continue;
      state.visited.add(bvid);
      state.order.push(bvid);
      added++;
    }
    return added;
  }

  async function extendQueue() {
    // 1) 个性化推荐流（与B站首页一致，抖音式）；rcmd item 自带 cid，可跳过 view 调用
    try {
      state.feedPage = (state.feedPage || 0) + 1;
      const j = await bgApi('https://api.bilibili.com/x/web-interface/index/top/feed/rcmd?fresh_idx=' + state.feedPage + '&ps=12');
      if (j.code === 0 && j.data && Array.isArray(j.data.item)) {
        let added = 0;
        for (const it of j.data.item) {
          if (!it || !it.bvid || state.visited.has(it.bvid)) continue;
          state.visited.add(it.bvid);
          state.order.push(it.bvid);
          added++;
        }
        // 注：不预构造 dataCache —— mountSlide 后 getView 拉取权威数据
        // （推荐流接口的 stat 字段名与 view 接口不一致且部分缺失，数字展示以官方 view 数据为准）
        if (added) { state.feedFail = 0; return added; }
      }
      state.feedFail = (state.feedFail || 0) + 1;
    } catch (e) {
      state.feedFail = (state.feedFail || 0) + 1;
    }
    // 2) 相关视频兜底
    const lastBvid = state.order[state.order.length - 1];
    let added = 0;
    try {
      const data = await getView(lastBvid);
      added = pushCandidates(data.related);
    } catch (e) { /* 单个视频相关列表失败不致命 */ }
    // 3) 热门兜底
    if (!added) {
      try {
        const j = await bgApi('https://api.bilibili.com/x/web-interface/popular?ps=20&pn=' + state.popularPage);
        if (j.code === 0 && j.data && Array.isArray(j.data.list)) {
          added = pushCandidates(j.data.list);
          state.popularPage++;
        }
      } catch (e) { /* 热门兜底失败 */ }
    }
    return added;
  }

  function prefetch(k) {
    const bvid = state.order[k];
    if (bvid && !dataCache.has(bvid)) getView(bvid).catch(() => {});
  }

  function currentSlide() {
    return state.slides.get(state.order[state.idx]) || null;
  }

  /* ---------------- MP4 工具函数（fMP4 Box 解析） ---------------- */

  function findFourcc(u8, s, from) {
    const a = s.charCodeAt(0), b = s.charCodeAt(1), c = s.charCodeAt(2), d = s.charCodeAt(3);
    for (let i = from || 0; i < u8.length - 4; i++) {
      if (u8[i] === a && u8[i + 1] === b && u8[i + 2] === c && u8[i + 3] === d) return i;
    }
    return -1;
  }
  function readU32(u8, o) { return ((u8[o] << 24) | (u8[o + 1] << 16) | (u8[o + 2] << 8) | u8[o + 3]) >>> 0; }
  function boxType(u8, o) { return String.fromCharCode(u8[o + 4], u8[o + 5], u8[o + 6], u8[o + 7]); }
  // 在 [start,end) 内遍历子 box
  function walkBoxes(u8, start, end, cb) {
    let o = start;
    while (o + 8 <= end) {
      const size = readU32(u8, o);
      const type = boxType(u8, o);
      if (size < 8) break;
      const bodyStart = o + 8;
      const bodyEnd = Math.min(o + size, end);
      if (cb(type, bodyStart, bodyEnd, o) === true) return true;
      o += size;
    }
    return false;
  }
  function parseTimescale(initU8) {
    let ts = 0;
    walkBoxes(initU8, 0, initU8.length, (type, s, e) => {
      if (type !== 'moov') return false;
      walkBoxes(initU8, s, e, (t2, s2, e2) => {
        if (t2 !== 'trak') return false;
        walkBoxes(initU8, s2, e2, (t3, s3, e3) => {
          if (t3 !== 'mdia') return false;
          walkBoxes(initU8, s3, e3, (t4, s4, e4) => {
            if (t4 !== 'mdhd') return false;
            const ver = initU8[s4];
            ts = ver === 1 ? readU32(initU8, s4 + 20) : readU32(initU8, s4 + 12);
            return true;
          });
          return ts ? true : false;
        });
        return ts ? true : false;
      });
      return ts ? true : false;
    });
    return ts || 1000;
  }
  function parseTfdt(u8, moofOff) {
    let val = -1;
    walkBoxes(u8, moofOff + 8, Math.min(moofOff + 512, u8.length), (type, s) => {
      if (type === 'tfdt') {
        const ver = u8[s];
        val = ver === 1
          ? readU32(u8, s + 12) * 4294967296 + readU32(u8, s + 16)
          : readU32(u8, s + 12);
        return true;
      }
      if (type === 'trun') return true;
      return false;
    });
    return val;
  }

  /* ---------------- DashPlayer（MSE 流式播放） ---------------- */

  const CHUNK = 4 * 1024 * 1024;
  const BUFFER_AHEAD = 25;

  class DashPlayer {
    constructor(video, dash, duration) {
      this.video = video;
      this.duration = duration || 0;
      const allV = (dash.video || []).slice().sort((a, b) => b.id - a.id);
      this.vlist = allV.filter((v) => v.codecid === 7);
      if (!this.vlist.length) this.vlist = allV;
      this.alist = (dash.audio || []).filter((a) => !a.codecs || String(a.codecs).indexOf('mp4a') === 0)
        .sort((a, b) => b.bandwidth - a.bandwidth);
      this.dead = false;
      this.seeking = false;
      this.seekQueue = null;
      this.seekBusy = false;
      this.timeOffset = 0;
      this.quality = 0;
      this.tracks = [];
      this.ms = null;
      this.url = null;
      this.errCount = 0;
      this.onFail = null;
      this.endedStream = false;
    }

    pickVideo(qn) {
      if (qn !== 'max' && qn) {
        const want = Number(qn);
        const exact = this.vlist.find((v) => v.id === want);
        if (exact) return exact;
        const lower = this.vlist.find((v) => v.id <= want);
        if (lower) return lower;
      }
      return this.vlist[0];
    }
    pickAudio() { return this.alist.length ? this.alist[0] : null; }

    trackSize(info) {
      return info.size || Math.max(1 << 20, Math.round((info.bandwidth || 2000000) / 8 * Math.max(1, this.duration)));
    }

    makeTrack(sb, info) {
      return { sb, info, size: this.trackSize(info), init: null, timescale: 1000, pos: 0, ac: null, done: false, pendingInit: false, initAppended: false };
    }

    fetchBuf(track, start, end) {
      const urls = [track.info.base_url].concat(track.info.backup_url || []).filter(Boolean);
      const ac = new AbortController();
      track.ac = ac;
      const timer = setTimeout(() => { try { ac.abort(); } catch (e) { } }, 12000);
      const attempt = async () => {
        let lastErr = null;
        try {
          for (const u of urls) {
            try {
              const r = await fetch(u.replace(/^http:/, 'https:'), {
                headers: { Range: 'bytes=' + start + '-' + end },
                signal: ac.signal,
                credentials: 'omit'
              });
              if (!r.ok && r.status !== 206) throw new Error('HTTP ' + r.status);
              const buf = await r.arrayBuffer();
              return buf;
            } catch (e) {
              lastErr = e;
              if (ac.signal.aborted) break;
            }
          }
          throw lastErr || new Error('分片拉取失败');
        } finally {
          clearTimeout(timer);
        }
      };
      return attempt();
    }

    appendOnce(track, buf) {
      return new Promise((res, rej) => {
        const sb = track.sb;
        const on = () => { cleanup(); res(); };
        const err = () => { cleanup(); rej(new Error('append error')); };
        const cleanup = () => { sb.removeEventListener('updateend', on); sb.removeEventListener('error', err); };
        sb.addEventListener('updateend', on);
        sb.addEventListener('error', err);
        try { sb.appendBuffer(buf); } catch (e) { cleanup(); rej(e); }
      });
    }

    async bootstrap(track) {
      // 渐进获取：init 段通常 <256KB，找不到 moof 再扩大
      let size = 262144;
      for (let i = 0; i < 3; i++) {
        const head = new Uint8Array(await this.fetchBuf(track, 0, size - 1));
        const moof = findFourcc(head, 'moof', 4);
        if (moof >= 0) {
          track.init = head.slice(0, moof);
          track.timescale = parseTimescale(track.init);
          track.pos = moof;
          return;
        }
        size = size * 4;
      }
      throw new Error('DASH 初始化段解析失败');
    }

    async open(vs, as_, startAt) {
      this.quality = vs.id;
      this.ms = new MediaSource();
      this.url = URL.createObjectURL(this.ms);
      this.video.src = this.url;
      await new Promise((res, rej) => {
        this.ms.addEventListener('sourceopen', res, { once: true });
        setTimeout(() => res(), 3000);
      });
      if (this.dead) return;
      try {
        const sbV = this.ms.addSourceBuffer(vs.mimeType + '; codecs="' + vs.codecs + '"');
        const tv = this.makeTrack(sbV, vs);
        this.tracks = [tv];
        if (as_) {
          const sbA = this.ms.addSourceBuffer(as_.mimeType + '; codecs="' + as_.codecs + '"');
          this.tracks.push(this.makeTrack(sbA, as_));
        }
      } catch (e) {
        throw new Error('浏览器不支持该编码：' + (vs.codecs || ''));
      }
      try { this.ms.duration = this.duration || 0; } catch (e) { /* 忽略 */ }
      await Promise.all(this.tracks.map((t) => this.bootstrap(t)));
      if (this.dead) return;
      if (startAt > 0.5) {
        const targetStream = startAt;
        for (const tr of this.tracks) {
          const est = Math.round(tr.size * targetStream / Math.max(1, this.duration));
          const loc = await this.locate(tr, Math.min(est, tr.size - 2), targetStream);
          tr.pos = loc.pos;
          tr.pendingInit = true;
        }
        this.timeOffset = startAt;
      }
      for (const tr of this.tracks) this.feedLoop(tr);
      if (startAt > 0.5) {
        try { this.video.currentTime = startAt; } catch (e) { /* 忽略 */ }
      }
    }

    async start(qn, startAt) {
      const vs = this.pickVideo(qn);
      await this.open(vs, this.pickAudio(), startAt || 0);
      return this.quality;
    }

    bufferedAhead(sb, t) {
      try {
        const b = sb.buffered;
        for (let i = 0; i < b.length; i++) {
          if (t >= b.start(i) - 0.2 && t <= b.end(i)) return b.end(i) - t;
        }
      } catch (e) { /* 忽略 */ }
      return 0;
    }
    inBuffer(sb, t) {
      try {
        const b = sb.buffered;
        for (let i = 0; i < b.length; i++) {
          if (t >= b.start(i) - 0.3 && t <= b.end(i)) return true;
        }
      } catch (e) { /* 忽略 */ }
      return false;
    }

    async feedLoop(track) {
      while (!this.dead && track.sb) {
        if (this.seeking) { await sleep(80); continue; }
        try {
          // init 段必须最先喂给 MSE（fresh start 或 seek 回退后）
          if (track.pendingInit || !track.initAppended) {
            track.sb.timestampOffset = this.timeOffset;
            await this.appendOnce(track, track.init);
            track.pendingInit = false;
            track.initAppended = true;
          }
          const ahead = this.bufferedAhead(track.sb, this.video.currentTime);
          if (ahead >= BUFFER_AHEAD || track.done) { await sleep(300); continue; }
          const start = track.pos;
          // 起播阶段用小分片快速出画面，缓冲充足后再用大分片
          const chunkSize = track.pos < 8 * 1024 * 1024 ? 1024 * 1024 : CHUNK;
          const end = Math.min(track.pos + chunkSize - 1, track.size - 1);
          if (start > end) {
            if (!track.done) {
              track.done = true;
              if (this.tracks.every((t) => t.done)) { try { this.ms.endOfStream(); } catch (e) { /* 忽略 */ } }
            }
            await sleep(300);
            continue;
          }
          const buf = await this.fetchBuf(track, start, end);
          if (this.dead) return;
          if (buf.byteLength === 0) { track.done = true; continue; }
          track.pos = start + buf.byteLength;
          await this.appendOnce(track, buf);
          this.errCount = 0;
          if (track.pos >= track.size) {
            track.done = true;
            if (this.tracks.every((t) => t.done)) { try { this.ms.endOfStream(); } catch (e) { /* 忽略 */ } }
          }
        } catch (e) {
          if (this.dead) return;
          this.errCount++;
          if (this.errCount >= 4) { this.fatal(e); return; }
          await sleep(400);
        }
      }
    }

    async locate(track, est, targetStreamSec) {
      const WIN = 262144;
      let off = Math.max(0, Math.min(est, track.size - 2) - 65536);
      for (let i = 0; i < 100; i++) {
        if (off >= track.size - 2048) off = Math.max(0, track.size - WIN);
        let buf;
        try { buf = await this.fetchBuf(track, off, off + WIN - 1); } catch (e) { break; }
        if (this.dead) break;
        const u8 = new Uint8Array(buf);
        const m = findFourcc(u8, 'moof', 0);
        if (m >= 0) {
          const abs = off + m;
          const ticks = parseTfdt(u8, m);
          const tfdtSec = ticks > 0 ? ticks / track.timescale : null;
          if (tfdtSec == null || tfdtSec >= targetStreamSec - 5 || off === 0) return { pos: abs, tfdt: tfdtSec };
          const remain = Math.max(0.5, targetStreamSec - tfdtSec);
          off += Math.max(WIN, Math.round(track.size * remain / Math.max(1, this.duration)));
          continue;
        }
        off += WIN - 4;
      }
      return { pos: Math.max(0, Math.min(est, track.size - 2)), tfdt: null };
    }

    requestSeek(t) {
      this.seekQueue = t;
      this.doSeek();
    }
    async doSeek() {
      if (this.seekBusy) return;
      this.seekBusy = true;
      while (this.seekQueue != null && !this.dead) {
        const t = this.seekQueue;
        this.seekQueue = null;
        try { await this.seek(t); } catch (e) { /* 定位失败继续原有喂流 */ }
      }
      this.seekBusy = false;
    }

    async seek(t) {
      if (this.dead || !this.tracks.length) return;
      const need = this.tracks.filter((tr) => !this.inBuffer(tr.sb, t));
      if (!need.length) return;
      this.seeking = true;
      for (const tr of this.tracks) { if (tr.ac) { try { tr.ac.abort(); } catch (e) { /* 忽略 */ } tr.ac = null; } }
      const targetStream = t - this.timeOffset;
      const plans = [];
      for (const tr of this.tracks) {
        if (this.inBuffer(tr.sb, t)) { plans.push({ tr, skip: true }); continue; }
        const b = tr.sb.buffered;
        const backwards = b.length === 0 || t < b.start(0) - 0.3;
        const est = Math.round(tr.size * Math.max(0, targetStream) / Math.max(1, this.duration));
        const loc = await this.locate(tr, est, targetStream);
        plans.push({ tr, skip: false, pos: loc.pos, tfdt: loc.tfdt, needInit: backwards });
      }
      let snapped = t;
      for (const pl of plans) {
        if (pl.skip) continue;
        const tr = pl.tr;
        try { tr.sb.abort(); } catch (e) { /* 忽略 */ }
        if (pl.needInit) {
          try { tr.sb.remove(0, 360000); } catch (e) { /* 忽略 */ }
          this.timeOffset = t - (pl.tfdt || 0);
          tr.pendingInit = true;
        } else if (pl.tfdt != null) {
          const elemStart = pl.tfdt + this.timeOffset;
          if (elemStart > snapped + 0.2) snapped = elemStart;
        }
        tr.pos = pl.pos;
      }
      this.seeking = false;
      if (Math.abs(this.video.currentTime - snapped) > 0.3) {
        try { this.video.currentTime = snapped; } catch (e) { /* 忽略 */ }
      }
    }

    fatal(e) {
      if (this.dead) return;
      this.dead = true;
      if (this.onFail) try { this.onFail(e); } catch (e2) { /* 忽略 */ }
    }

    destroy() {
      this.dead = true;
      for (const tr of this.tracks) { if (tr.ac) { try { tr.ac.abort(); } catch (e) { /* 忽略 */ } } }
      try { if (this.ms && this.ms.readyState === 'open') this.ms.endOfStream(); } catch (e) { /* 忽略 */ }
      try { URL.revokeObjectURL(this.url); } catch (e) { /* 忽略 */ }
      this.tracks = [];
      this.ms = null;
    }
  }

  /* ---------------- 弹幕引擎 ---------------- */

  function parseDmXml(xml) {
    const out = [];
    const re = /<d p="([^"]+)"[^>]*>([\s\S]*?)<\/d>/g;
    let m;
    while ((m = re.exec(xml))) {
      const p = m[1].split(',');
      const mode = parseInt(p[1], 10) || 1;
      if (mode < 1 || mode > 5) continue;
      out.push({
        t: parseFloat(p[0]) || 0,
        mode,
        size: parseInt(p[2], 10) || 25,
        color: parseInt(p[3], 10) || 0xffffff,
        text: decodeEntities(m[2].replace(/<[^>]*>/g, '')).trim()
      });
    }
    out.sort((a, b) => a.t - b.t);
    return out;
  }

  class Danmaku {
    constructor(slide) {
      this.slide = slide;
      this.items = [];
      this.live = [];
      this.on = !!settings.danmakuOn;
      this.lastT = -1;
      this.lastFrame = 0;
      this.canvas = null;
      this.ctx = null;
      this.raf = 0;
      this.dead = false;
      this.frameN = 0;
    }
    async load() {
      const errs = [];
      const items = [];
      const diag = [];
      // 1) 官方分段 protobuf 接口（WBI 签名 + dm 设备风控参数，播放器同款）；每段 6 分钟
      try {
        const dur = Math.max(1, (this.slide.data && this.slide.data.duration) || 1);
        const segs = Math.min(16, Math.ceil(dur / 360));
        for (let s = 1; s <= segs; s++) {
          try {
            // dm_img_list 等为风控参数（2023+ 必须，社区通用伪造值），需参与 WBI 签名
            const base = 'https://api.bilibili.com/x/v2/dm/wbi/web/seg.so?type=1&oid=' + this.slide.cid +
              '&segment_index=' + s +
              '&dm_img_list=%5B%5D&dm_img_str=base64&dm_cover_img_str=base64' +
              '&dm_img_inter=%7B%22ds%22%3A%5B%5D%2C%22wh%22%3A%5B0%2C0%2C0%5D%2C%22of%22%3A%5B0%2C0%2C0%5D%7D';
            const su = await wbiSignC(base);
            const res = await fetch(su, { credentials: 'include' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const buf = new Uint8Array(await res.arrayBuffer());
            const top = parsePb(buf);
            const elems = top[1] || [];
            diag.push('seg' + s + ':bytes=' + buf.length + ',elems=' + elems.length);
            let elemDiag = '';
            let modeDiag = '';
            for (const raw of elems) {
              let d = null;
              try { d = parsePbElem(raw); }
              catch (e) { if (!elemDiag) elemDiag = 'elemerr:' + shortErr(e); continue; }
              if (d.text) {
                if (modeDiag === '') modeDiag = 'mode=' + d.mode + ',fs=' + d.fontsize;
                // 仅剔除特殊/代码弹幕（7+），1-3 滚动、4 底部、5 顶部保留
                items.push({ t: d.progress / 1000, mode: (d.mode >= 1 && d.mode <= 5) ? d.mode : 1, size: d.fontsize, color: d.color, text: d.text });
              } else if (!elemDiag) {
                const hh = [];
                for (let i = 0; i < Math.min(28, raw.length); i++) hh.push(raw[i].toString(16).padStart(2, '0'));
                elemDiag = 'elem0hex=' + hh.join('');
              }
            }
            if (s === 1) {
              if (elemDiag) diag.push(elemDiag);
              if (modeDiag) diag.push(modeDiag);
            }
          } catch (e) { errs.push('seg' + s + ':' + shortErr(e)); }
        }
        items.sort((a, b) => a.t - b.t);
      } catch (e) { errs.push('seg:' + shortErr(e)); }
      // 2) 老全量 XML 接口兜底
      if (!items.length) {
        try {
          const res = await fetch('https://api.bilibili.com/x/v1/dm/list.so?oid=' + this.slide.cid, { credentials: 'include' });
          if (!res.ok) throw new Error('HTTP ' + res.status);
          const buf = await res.arrayBuffer();
          const u8 = new Uint8Array(buf);
          let xml;
          if (u8.length > 2 && u8[0] === 0x78 && typeof DecompressionStream !== 'undefined') {
            xml = await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('deflate'))).text();
          } else xml = new TextDecoder('utf-8').decode(buf);
          items.push(...parseDmXml(xml));
        } catch (e) { errs.push('so:' + shortErr(e)); }
      }
      this.items = items;
      if (!this.items.length && state.active) {
        const head = diag.filter((d) => d.indexOf('elem0') === 0 || d.indexOf('mode=') === 0 || d.indexOf('elemerr') === 0);
        const tail = diag.filter((d) => d.indexOf('seg') === 0).slice(0, 2);
        showToast('弹幕加载失败 → ' + head.concat(tail).concat(errs.slice(0, 2)).join(' | '), 25000);
      }
      if (!this.dead) this.startPtr = 0;
    }
    mount() {
      const el = document.createElement('canvas');
      el.className = 'dm-canvas';
      this.slide.el.insertBefore(el, this.slide.el.querySelector('.info'));
      this.canvas = el;
      this.ctx = el.getContext('2d');
      this.resize();
      this.raf = requestAnimationFrame(this.tick);
    }
    resize() {
      if (!this.canvas || !this.slide.el) return;
      const r = this.slide.el.getBoundingClientRect();
      if (!r.width) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      this.canvas.width = Math.round(r.width * dpr);
      this.canvas.height = Math.round(r.height * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.W = r.width;
      this.H = r.height;
      this.rows = Math.max(3, Math.floor(this.H * 0.45 / 26));
      this.fixedTop = Math.max(2, Math.floor(this.rows / 3));
      this.laneEnd = new Array(this.rows).fill(-1e9);
      this.laneSpeed = new Array(this.rows).fill(0);
      this.fixedSlots = [];
    }
    setOn(on) {
      this.on = !!on;
      if (!on) { this.live = []; this.fixedSlots = []; }
    }
    fontPx(size) { return size <= 18 ? 14 : size <= 25 ? 19 : 26; }
    colorHex(c) { return '#' + (c & 0xffffff).toString(16).padStart(6, '0'); }
    spawn(it) {
      if (!this.on || !this.ctx) return;
      const ctx = this.ctx;
      ctx.font = this.fontPx(it.size) + 'px "PingFang SC","Microsoft YaHei",sans-serif';
      const w = ctx.measureText(it.text).width;
      if (it.mode === 4 || it.mode === 5) {
        if (this.fixedSlots.length >= 4) return;
        this.fixedSlots.push({ it, w, born: this.slide.video.currentTime });
        return;
      }
      if (this.live.length > 70) return;
      let lane = -1;
      for (let i = 0; i < this.rows; i++) {
        if (this.laneEnd[i] < this.W - 40) { lane = i; break; }
      }
      if (lane < 0) return;
      const speed = (this.W + 20 + w) / 8.5;
      this.live.push({ it, w, x: this.W + 10, lane, speed });
      this.laneEnd[lane] = this.W + 10 + w;
      this.laneSpeed[lane] = speed;
    }
    tick = (ts) => {
      if (this.dead) return;
      this.raf = requestAnimationFrame(this.tick);
      if (currentSlide() !== this.slide) { this.lastT = -1; return; }
      if (++this.frameN % 90 === 0) this.resize();
      const v = this.slide.video;
      const t = v.currentTime;
      const dt = Math.min(0.12, (ts - this.lastFrame) / 1000) || 0;
      this.lastFrame = ts;
      if (!this.ctx) return;
      if (this.lastT < 0 || t < this.lastT - 0.5 || t > this.lastT + 2) {
        this.live = [];
        this.fixedSlots = [];
        this.lastT = t;
        this.startPtr = this.findPtr(t);
      } else if (t > this.lastT) {
        while (this.startPtr < this.items.length && this.items[this.startPtr].t <= t) {
          const it = this.items[this.startPtr++];
          if (it.t > this.lastT) this.spawn(it);
        }
        this.lastT = t;
      }
      const ctx = this.ctx;
      ctx.clearRect(0, 0, this.W, this.H);
      ctx.globalAlpha = 0.9;
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(0,0,0,.75)';
      ctx.textBaseline = 'middle';
      const moving = !v.paused;
      for (let i = this.live.length - 1; i >= 0; i--) {
        const d = this.live[i];
        if (moving) d.x -= d.speed * dt;
        if (d.x + d.w < -20) { this.live.splice(i, 1); continue; }
        ctx.font = this.fontPx(d.it.size) + 'px "PingFang SC","Microsoft YaHei",sans-serif';
        const y = 14 + d.lane * 26;
        ctx.strokeText(d.it.text, d.x, y);
        ctx.fillStyle = this.colorHex(d.it.color);
        ctx.fillText(d.it.text, d.x, y);
      }
      for (let i = this.fixedSlots.length - 1; i >= 0; i--) {
        const f = this.fixedSlots[i];
        if (t - f.born > 5) { this.fixedSlots.splice(i, 1); continue; }
        ctx.font = this.fontPx(f.it.size) + 'px "PingFang SC","Microsoft YaHei",sans-serif';
        const y = f.it.mode === 5 ? 14 + i * 26 : this.H * 0.72 + i * 26;
        const x = (this.W - f.w) / 2;
        ctx.strokeText(f.it.text, x, y);
        ctx.fillStyle = this.colorHex(f.it.color);
        ctx.fillText(f.it.text, x, y);
      }
      // 滚动车道释放
      for (const d of this.live) {
        const end = d.x + d.w;
        if (this.laneEnd[d.lane] < end) this.laneEnd[d.lane] = end;
      }
    };
    findPtr(t) {
      let lo = 0, hi = this.items.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (this.items[mid].t <= t) lo = mid + 1; else hi = mid; }
      return lo;
    }
    destroy() {
      this.dead = true;
      if (this.raf) cancelAnimationFrame(this.raf);
      if (this.canvas) this.canvas.remove();
    }
  }

  function loadDanmaku(slide) {
    if (slide.danmaku || !slide.cid) return;
    const dm = new Danmaku(slide);
    slide.danmaku = dm;
    // 延迟拉取弹幕，避免与视频流抢带宽
    setTimeout(() => {
      if (dm.dead || !slide.el.isConnected) return;
      dm.load().then(() => { if (!dm.dead && slide.el.isConnected) dm.mount(); });
    }, 1200);
  }

  /* ---------------- UI 构建 ---------------- */

  function buildUI() {
    if (host) return;
    host = document.createElement('div');
    host.id = 'bili-shorts-host';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';
    shadow = host.attachShadow({ mode: 'open' });
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS_TEXT);
      shadow.adoptedStyleSheets = [sheet];
    } catch (e) {
      const style = document.createElement('style');
      style.textContent = CSS_TEXT;
      shadow.appendChild(style);
    }
    const root = document.createElement('div');
    root.className = 'root';
    root.innerHTML =
      '<div class="viewport"></div>' +
      '<div class="topbar">' +
        '<div class="brand"><span class="dot"></span><span>竖刷模式</span></div>' +
        '<div class="top-actions">' +
          '<button class="icon-btn" data-act="q" title="清晰度"><span data-ref="qlabel">…</span></button>' +
          '<button class="icon-btn" data-act="dm" title="弹幕开关 (B)"><span>弹</span></button>' +
          '<button class="icon-btn" data-act="cmt" title="查看评论 (X)">' + ICON.bubble + '</button>' +
          '<button class="icon-btn" data-act="fill" title="切换画面填充 (C)">' + ICON.fit + '</button>' +
          '<button class="icon-btn" data-act="mute" title="静音 (M)">' +
            '<span class="i-vol">' + ICON.volume + '</span><span class="i-mut">' + ICON.mute + '</span>' +
          '</button>' +
          '<button class="icon-btn" data-act="fs" title="全屏 (F)">' + ICON.fs + '</button>' +
          '<button class="icon-btn" data-act="close" title="退出 (Esc)">' + ICON.close + '</button>' +
        '</div>' +
      '</div>' +
      '<div class="cmt-panel"><div class="cmt-head">' +
          '<span>评论</span><span class="cnt" data-ref="ccount"></span><span class="sp"></span>' +
          '<button class="cmt-close" data-act="cmtclose">›</button>' +
        '</div><div class="cmt-list" data-ref="clist"><div class="cmt-more">加载中…</div></div></div>' +
      '<button class="cmt-tab" data-act="cmttab" title="查看评论">评论</button>' +
      '<div class="qmenu" hidden></div>' +
      '<div class="bottombar">' +
        '<span class="time" data-ref="tc">0:00</span>' +
        '<div class="progress" data-act="progress"><div class="trackbg">' +
          '<div class="buffered"></div><div class="played"></div><div class="knob"></div>' +
        '</div></div>' +
        '<span class="time" data-ref="td">0:00</span>' +
      '</div>' +
      '<div class="toast"></div>';
    shadow.appendChild(root);
    ui = {
      root,
      viewport: root.querySelector('.viewport'),
      toastEl: root.querySelector('.toast'),
      timeCur: root.querySelector('[data-ref="tc"]'),
      timeDur: root.querySelector('[data-ref="td"]'),
      progress: root.querySelector('[data-act="progress"]'),
      trackbg: root.querySelector('.trackbg'),
      buffered: root.querySelector('.buffered'),
      played: root.querySelector('.played'),
      knob: root.querySelector('.knob'),
      qBtn: root.querySelector('[data-act="q"]'),
      qLabel: root.querySelector('[data-ref="qlabel"]'),
      qMenu: root.querySelector('.qmenu'),
      dmBtn: root.querySelector('[data-act="dm"]'),
      muteBtn: root.querySelector('[data-act="mute"]'),
      cmtPanel: root.querySelector('.cmt-panel'),
      cmtTab: root.querySelector('[data-act="cmttab"]'),
      cmtList: root.querySelector('[data-ref="clist"]'),
      cmtCount: root.querySelector('[data-ref="ccount"]')
    };
    syncMuteIcon();
    ui.dmBtn.classList.toggle('off', !settings.danmakuOn);

    host.addEventListener('wheel', onWheel, { passive: false });
    ui.viewport.addEventListener('touchstart', onTouchStart, { passive: true });
    ui.viewport.addEventListener('touchmove', onTouchMove, { passive: false });
    ui.viewport.addEventListener('touchend', onTouchEnd, { passive: true });
    ui.qBtn.addEventListener('click', (e) => { toggleQMenu(); e.currentTarget.blur(); });
    ui.dmBtn.addEventListener('click', (e) => { toggleDanmaku(); e.currentTarget.blur(); });
    root.querySelector('[data-act="cmt"]').addEventListener('click', (e) => { toggleComments(); e.currentTarget.blur(); });
    ui.cmtTab.addEventListener('click', () => { toggleComments(true); });
    root.querySelector('[data-act="cmtclose"]').addEventListener('click', () => { toggleComments(false); });
    ui.cmtList.addEventListener('scroll', () => {
      const el = ui.cmtList;
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 80) loadComments();
    });
    root.querySelector('[data-act="fill"]').addEventListener('click', (e) => { toggleFill(); e.currentTarget.blur(); });
    ui.muteBtn.addEventListener('click', (e) => { toggleMute(); e.currentTarget.blur(); });
    root.querySelector('[data-act="fs"]').addEventListener('click', (e) => { toggleFullscreen(); e.currentTarget.blur(); });
    root.querySelector('[data-act="close"]').addEventListener('click', () => exit());
    document.addEventListener('click', onDocClickForMenu, true);
    bindProgress();
    document.body.appendChild(host);
    requestAnimationFrame(() => root.classList.add('on'));
  }

  function onDocClickForMenu(e) {
    if (!state.active || !ui.qMenu || ui.qMenu.hidden) return;
    const p = e.composedPath ? e.composedPath() : [];
    if (!p.includes(ui.qMenu) && !p.includes(ui.qBtn)) ui.qMenu.hidden = true;
  }

  function syncMuteIcon() {
    if (!ui.muteBtn) return;
    const s = currentSlide();
    const muted = state.forceMuted || settings.muted || !!(s && s.video.muted);
    ui.muteBtn.classList.toggle('muted', muted);
  }

  function bindProgress() {
    const el = ui.progress;
    const ratioFromEvent = (e) => {
      const r = ui.trackbg.getBoundingClientRect();
      return Math.min(1, Math.max(0, (e.clientX - r.left) / Math.max(1, r.width)));
    };
    const apply = (e, commit) => {
      const s = currentSlide();
      if (!s) return;
      const v = s.video;
      const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : 0;
      if (!dur) return;
      const ratio = ratioFromEvent(e);
      ui.played.style.width = (ratio * 100) + '%';
      ui.knob.style.left = (ratio * 100) + '%';
      if (commit) v.currentTime = ratio * dur;
    };
    el.addEventListener('pointerdown', (e) => { seeking = true; try { el.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ } apply(e, false); });
    el.addEventListener('pointermove', (e) => { if (seeking) apply(e, false); });
    el.addEventListener('pointerup', (e) => { if (!seeking) return; seeking = false; apply(e, true); });
    el.addEventListener('pointercancel', () => { seeking = false; });
  }

  /* ---------------- Slide ---------------- */

  function mountSlide(bvid, pageParam) {
    const el = document.createElement('div');
    el.className = 'slide';
    el.dataset.bvid = bvid;
    el.innerHTML =
      '<video class="player" playsinline preload="auto"></video>' +
      '<div class="shade"></div>' +
      '<div class="info">' +
        '<div class="owner"><img class="avatar" alt=""><span class="owner-name"></span></div>' +
        '<div class="title" title="点击打开原视频"></div>' +
        '<div class="meta"><span class="q"></span><span class="mt"></span></div>' +
      '</div>' +
      '<div class="rail">' +
        '<div class="rail-item like"><button class="rail-btn" title="点赞">' + ICON.heart + '</button><span class="rail-count">-</span></div>' +
        '<div class="rail-item coin"><button class="rail-btn" title="投币">' + ICON.coin + '</button><span class="rail-count">-</span></div>' +
        '<div class="rail-item fav"><button class="rail-btn" title="收藏到默认收藏夹">' + ICON.star + '</button><span class="rail-count">-</span></div>' +
        '<div class="rail-item share"><button class="rail-btn" title="复制链接分享">' + ICON.share + '</button><span class="rail-count">-</span></div>' +
        '<div class="rail-item open"><button class="rail-btn" title="打开原视频">' + ICON.open + '</button><span class="rail-count"></span></div>' +
      '</div>' +
      '<div class="center-msg" hidden><div class="msg-text"></div><div class="msg-actions"></div></div>' +
      '<div class="spin" hidden><div class="spinner"></div></div>';

    const slide = {
      bvid, pageParam: pageParam || 0, el,
      video: el.querySelector('video'),
      loadState: null, mode: null, urls: [], urlIdx: 0, quality: 0,
      data: null, cid: 0, dash: null, avail: null,
      player: null, danmaku: null, mp4Tried: false, qBusy: false, retried: false
    };

    slide.video.style.objectFit = settings.fill === 'cover' ? 'cover' : 'contain';
    slide.video.addEventListener('click', () => togglePlay(slide));
    slide.video.addEventListener('loadedmetadata', () => { if (currentSlide() === slide) updateProgressUI(slide); });
    slide.video.addEventListener('timeupdate', () => { if (currentSlide() === slide) updateProgressUI(slide); });
    slide.video.addEventListener('progress', () => { if (currentSlide() === slide) updateBuffered(slide); });
    slide.video.addEventListener('waiting', () => { if (currentSlide() === slide) showSpin(slide, true); });
    slide.video.addEventListener('playing', () => showSpin(slide, false));
    slide.video.addEventListener('canplay', () => showSpin(slide, false));
    slide.video.addEventListener('seeking', () => {
      if (slide.player && slide.mode === 'dash') slide.player.requestSeek(slide.video.currentTime);
      if (slide.danmaku) slide.danmaku.lastT = -1;
    });
    slide.video.addEventListener('ended', () => {
      if (currentSlide() !== slide) return;
      if (settings.autoNext) go(1);
      else showMsg(slide, '播放结束', [{ label: '重新播放', fn: () => { hideMsg(slide); slide.video.currentTime = 0; playSlide(slide); } }]);
    });
    slide.video.addEventListener('error', () => onVideoError(slide));

    el.querySelector('.title').addEventListener('click', () => window.open('https://www.bilibili.com/video/' + bvid + '/', '_blank'));
    el.querySelector('.owner').addEventListener('click', () => {
      if (slide.data) window.open('https://space.bilibili.com/' + slide.data.owner.mid, '_blank');
    });
    el.querySelector('.like .rail-btn').addEventListener('click', (e) => { doLike(slide, e.currentTarget); e.currentTarget.blur(); });
    el.querySelector('.coin .rail-btn').addEventListener('click', (e) => { doCoin(slide, e.currentTarget); e.currentTarget.blur(); });
    el.querySelector('.fav .rail-btn').addEventListener('click', (e) => { doFav(slide, e.currentTarget); e.currentTarget.blur(); });
    el.querySelector('.share .rail-btn').addEventListener('click', () => doShare(slide));
    el.querySelector('.open .rail-btn').addEventListener('click', () => window.open('https://www.bilibili.com/video/' + bvid + '/', '_blank'));

    state.slides.set(bvid, slide);
    ui.viewport.appendChild(el);
    loadSlide(slide);
    return slide;
  }

  function unmountSlide(slide) {
    try { if (slide.player) slide.player.destroy(); } catch (e) { /* 忽略 */ }
    try { if (slide.danmaku) slide.danmaku.destroy(); } catch (e) { /* 忽略 */ }
    slide.player = null; slide.danmaku = null;
    try { slide.video.pause(); } catch (e) { /* 忽略 */ }
    try { slide.video.removeAttribute('src'); slide.video.load(); } catch (e) { /* 忽略 */ }
    slide.el.remove();
  }

  async function loadSlide(slide) {
    if (slide.loadState) return;
    slide.loadState = 'loading';
    showSpin(slide, true);
    try {
      const data = await getView(slide.bvid);
      slide.data = data;
      let page = (data.pages && data.pages.length) ? data.pages[0] : null;
      if (slide.pageParam > 1 && data.pages && data.pages[slide.pageParam - 1]) {
        page = data.pages[slide.pageParam - 1];
      }
      slide.cid = page ? page.cid : data.cid;
      fillInfo(slide, data, page);
      await attachPlayback(slide, 0);
      slide.loadState = 'ready';
      showSpin(slide, false);
      if (state.order[state.idx] === slide.bvid) {
        playSlide(slide);
        updateTitle(slide);
        updateQLabel(slide);
      }
    } catch (err) {
      slide.loadState = 'error';
      showSpin(slide, false);
      showMsg(slide, '加载失败：' + ((err && err.message) || err), [
        { label: '重试', fn: () => { slide.loadState = null; hideMsg(slide); loadSlide(slide); } },
        { label: '打开原视频', ghost: true, fn: () => window.open('https://www.bilibili.com/video/' + slide.bvid + '/', '_blank') }
      ]);
    }
  }

  // DASH 优先（登录可解锁1080P+），失败回退 html5 直连 MP4（720P上限）
  async function attachPlayback(slide, startAt) {
    let dashOk = false;
    if (typeof MediaSource !== 'undefined' && window.MediaSource) {
      try {
        const p = await getPlayDash(slide.bvid, slide.cid);
        const dash = p.dash;
        if (dash && Array.isArray(dash.video) && dash.video.length) {
          slide.dash = dash;
          slide.avail = p.support_formats || null;
          slide.mode = 'dash';
          slide.player = new DashPlayer(slide.video, dash, slide.data ? slide.data.duration : 0);
          slide.player.onFail = () => {
            if (!slide.mp4Tried && state.active) {
              showToast('DASH 播放异常，已回退直连模式（最高720P）');
              mp4Fallback(slide, slide.video.currentTime).catch(() => {});
            }
          };
          slide.quality = await slide.player.start(settings.dashQn, startAt || 0);
          dashOk = true;
        }
      } catch (e) { dashOk = false; }
    }
    if (!dashOk) await mp4Fallback(slide, startAt);
    loadDanmaku(slide);
  }

  async function mp4Fallback(slide, startAt) {
    slide.mode = 'mp4';
    if (slide.player) { try { slide.player.destroy(); } catch (e) { /* 忽略 */ } slide.player = null; }
    const m = await getPlayMp4(slide.bvid, slide.cid);
    slide.urls = m.urls;
    slide.urlIdx = 0;
    slide.quality = m.quality;
    slide.avail = null;
    setSrc(slide, m.urls[0]);
    updateQLabel(slide);
    if (startAt > 0) {
      const v = slide.video;
      const on = () => { try { v.currentTime = startAt; } catch (e) { /* 忽略 */ } v.removeEventListener('loadedmetadata', on); };
      v.addEventListener('loadedmetadata', on);
    }
  }

  function fillInfo(slide, data, page) {
    const el = slide.el;
    el.querySelector('.avatar').src = (data.owner && data.owner.face || '').replace(/^http:/, 'https:');
    el.querySelector('.owner-name').textContent = data.owner ? data.owner.name : '';
    const partSuffix = (page && data.pages && data.pages.length > 1 && page.page > 1)
      ? ' · P' + page.page + ' ' + (page.part || '') : '';
    el.querySelector('.title').textContent = data.title + partSuffix;
    const meta = [
      fmtCount(data.stat && data.stat.view) + ' 播放',
      fmtCount(data.stat && data.stat.danmaku) + ' 弹幕',
      fmtTime(data.duration),
      fmtDate(data.pubdate)
    ];
    el.querySelector('.mt').textContent = meta.join(' · ');
    el.querySelector('.like .rail-count').textContent = fmtCount(data.stat && data.stat.like);
    el.querySelector('.coin .rail-count').textContent = fmtCount(data.stat && data.stat.coin);
    el.querySelector('.fav .rail-count').textContent = fmtCount(data.stat && data.stat.favorite);
    el.querySelector('.share .rail-count').textContent = fmtCount(data.stat && data.stat.share);
    if (isLogged()) {
      const btnLike = el.querySelector('.like .rail-btn');
      const btnCoin = el.querySelector('.coin .rail-btn');
      const btnFav = el.querySelector('.fav .rail-btn');
      directGet('https://api.bilibili.com/x/web-interface/archive/has/like?bvid=' + slide.bvid)
        .then((j) => { if (j.code === 0 && j.data === 1) btnLike.classList.add('on'); }).catch(() => {});
      directGet('https://api.bilibili.com/x/web-interface/archive/has/coin?bvid=' + slide.bvid)
        .then((j) => { if (j.code === 0 && Number(j.data) > 0) btnCoin.classList.add('on'); }).catch(() => {});
      directGet('https://api.bilibili.com/x/v2/fav/video/favoured?aid=' + data.aid)
        .then((j) => { if (j.code === 0 && j.data === true) btnFav.classList.add('on'); }).catch(() => {});
    }
    // 视频信息就绪：若评论面板开着，立即刷新为当前视频的评论
    if (cmt.open && state.order[state.idx] === slide.bvid) cmtSync();
    if (state.order[state.idx] === slide.bvid) updateTitle(slide);
  }

  function updateTitle(slide) {
    if (state.active && slide.data) document.title = '▶ ' + slide.data.title + ' - 竖刷';
  }

  function setSrc(slide, url) {
    slide.urlIdx = slide.urls.indexOf(url);
    slide.video.src = url;
    slide.video.load();
  }

  function onVideoError(slide) {
    if (!slide.el || !slide.el.isConnected) return;
    if (slide.mode !== 'mp4' || slide.loadState !== 'ready') return;
    const next = slide.urls[slide.urlIdx + 1];
    if (next) {
      setSrc(slide, next);
      if (currentSlide() === slide) playSlide(slide);
      return;
    }
    if (!slide.retried) {
      slide.retried = true;
      setSrc(slide, slide.urls[0]);
      if (currentSlide() === slide) playSlide(slide);
      return;
    }
    showMsg(slide, '视频加载失败，可能是网络问题或该视频不支持网页播放', [
      { label: '重试', fn: () => { hideMsg(slide); setSrc(slide, slide.urls[0]); if (currentSlide() === slide) playSlide(slide); } },
      { label: '打开原视频', ghost: true, fn: () => window.open('https://www.bilibili.com/video/' + slide.bvid + '/', '_blank') }
    ]);
  }

  async function playSlide(slide) {
    const v = slide.video;
    try {
      await v.play();
      syncMuteIcon();
    } catch (e) {
      try {
        v.muted = true;
        state.forceMuted = true;
        await v.play();
        showToast('浏览器限制了自动播放声音，已静音播放。点击右上角喇叭或按 M 恢复声音');
        syncMuteIcon();
      } catch (e2) { /* 等待用户操作 */ }
    }
  }

  /* ---------------- 清晰度菜单 ---------------- */

  function availList(slide) {
    if (!slide) return [];
    if (slide.mode === 'dash') {
      const ids = Array.from(new Set((slide.dash && slide.dash.video || []).map((v) => v.id)));
      return ids.sort((a, b) => b - a).map((id) => ({ id, label: qlabel(id, slide.avail) }));
    }
    if (slide.mode === 'mp4') {
      return [{ id: 64, label: '720P' }, { id: 32, label: '480P' }, { id: 16, label: '360P' }];
    }
    return [];
  }

  function updateQLabel(slide) {
    if (!ui.qLabel) return;
    const s = slide || currentSlide();
    if (!s || !s.quality) { ui.qLabel.textContent = '…'; return; }
    ui.qLabel.textContent = qlabel(s.quality, s.avail) || s.quality + 'P';
  }

  function toggleQMenu() {
    const s = currentSlide();
    if (!ui.qMenu || !s || s.qBusy) return;
    if (!ui.qMenu.hidden) { ui.qMenu.hidden = true; return; }
    const list = availList(s);
    if (!list.length) { showToast('当前视频暂无其他清晰度'); return; }
    ui.qMenu.innerHTML = '';
    for (const item of list) {
      const div = document.createElement('div');
      div.className = 'qmi' + (item.id === s.quality ? ' cur' : '');
      div.innerHTML = '<span>' + item.label + '</span>' + (item.id === s.quality ? '<span>✓</span>' : '');
      div.addEventListener('click', () => { ui.qMenu.hidden = true; switchQuality(s, item.id); });
      ui.qMenu.appendChild(div);
    }
    ui.qMenu.hidden = false;
  }

  async function switchQuality(slide, qid) {
    if (!slide || slide.qBusy || qid === slide.quality) return;
    slide.qBusy = true;
    const t = slide.video.currentTime;
    const wasPlaying = !slide.video.paused;
    try {
      if (slide.mode === 'dash' && slide.dash) {
        slide.player.destroy();
        slide.player = new DashPlayer(slide.video, slide.dash, slide.data.duration);
        slide.player.onFail = () => {
          if (!slide.mp4Tried && state.active) mp4Fallback(slide, slide.video.currentTime).catch(() => {});
        };
        slide.quality = await slide.player.start(qid, t);
        settings.dashQn = qid;
        try { chrome.storage.sync.set({ dashQn: qid }); } catch (e) { /* 忽略 */ }
      } else if (slide.mode === 'mp4') {
        settings.qnTmp = qid;
        const key = slide.bvid + '|' + slide.cid + '|' + qid;
        const j = await bgApi('https://api.bilibili.com/x/player/playurl?bvid=' + encodeURIComponent(slide.bvid) +
          '&cid=' + slide.cid + '&qn=' + qid + '&fnval=0&fnver=0&platform=html5&high_quality=' + (qid >= 64 ? 1 : 0));
        if (j.code === 0 && j.data && j.data.durl && j.data.durl.length) {
          const urls = [];
          for (const d of j.data.durl) {
            if (d.url) urls.push(d.url.replace(/^http:/, 'https:'));
            if (d.backup_url) for (const u of d.backup_url) if (u) urls.push(u.replace(/^http:/, 'https:'));
          }
          urlCache.set(key, { urls, quality: j.data.quality || qid });
          slide.urls = urls;
          slide.quality = j.data.quality || qid;
          setSrc(slide, urls[0]);
          const v = slide.video;
          const on = () => { try { v.currentTime = t; } catch (e) { /* 忽略 */ } v.removeEventListener('loadedmetadata', on); };
          v.addEventListener('loadedmetadata', on);
        }
      }
      updateQLabel(slide);
      showToast('清晰度已切换：' + qlabel(slide.quality, slide.avail));
      if (wasPlaying) playSlide(slide);
    } catch (e) {
      showToast('切换失败：' + ((e && e.message) || e));
      updateQLabel(slide);
    }
    slide.qBusy = false;
  }

  /* ---------------- 切换逻辑 ---------------- */

  function setIndex(i) {
    state.idx = i;
    const keep = new Set();
    const delayed = [];
    for (let k = i - 1; k <= i + 1; k++) {
      const bvid = state.order[k];
      if (!bvid) continue;
      keep.add(bvid);
      if (!state.slides.has(bvid)) {
        if (k === i) mountSlide(bvid, k === 0 ? state.seedPage : 0);
        else delayed.push(k);
      }
    }
    for (const [bvid, s] of Array.from(state.slides)) {
      if (!keep.has(bvid)) { unmountSlide(s); state.slides.delete(bvid); }
    }
    // 邻居视频延迟挂载：先让当前视频完成起播，避免抢带宽导致黑屏
    for (const k of delayed) {
      const bvid = state.order[k];
      const pageParam = k === 0 ? state.seedPage : 0;
      setTimeout(() => {
        if (!state.active) return;
        const pos = state.order.indexOf(bvid);
        if (pos === -1 || Math.abs(pos - state.idx) > 1) return;
        if (!state.slides.has(bvid)) mountSlide(bvid, pageParam);
      }, 900);
    }
    layout();
    const cur = state.slides.get(state.order[i]);
    if (cur && cur.loadState === 'ready') playSlide(cur);
    const prev = state.slides.get(state.order[i - 1]);
    if (prev) try { prev.video.pause(); } catch (e) { /* 忽略 */ }
    const next = state.slides.get(state.order[i + 1]);
    if (next) try { next.video.pause(); } catch (e) { /* 忽略 */ }
    updateProgressUI(cur);
    updateBuffered(cur);
    updateTitle(cur);
    updateQLabel(cur);
    cmtSync();
    if (ui.qMenu) ui.qMenu.hidden = true;
    if (state.order.length - i <= 3) extendQueue().catch(() => { /* 忽略 */ });
    prefetch(i + 1);
    prefetch(i + 2);
  }

  function layout() {
    state.order.forEach((bvid, k) => {
      const s = state.slides.get(bvid);
      if (!s) return;
      const off = k - state.idx;
      s.el.classList.toggle('active', off === 0);
      s.el.classList.toggle('above', off < 0);
      s.el.style.transform = 'translateY(' + (off > 0 ? 100 : off < 0 ? -100 : 0) + '%)';
    });
  }

  async function go(delta) {
    if (!state.active || state.locked) return;
    const target = state.idx + delta;
    if (target < 0) { showToast('已经是第一个视频了'); return; }
    if (target >= state.order.length) {
      if (state.extending) return;
      state.extending = true;
      showToast('正在加载更多视频…');
      let added = 0;
      try { added = await extendQueue(); } catch (e) { /* 忽略 */ }
      state.extending = false;
      if (!added) { showToast('暂时没有更多视频了'); return; }
    }
    if (target >= state.order.length) return;
    state.locked = true;
    setTimeout(() => { state.locked = false; }, 480);
    setIndex(target);
  }

  /* ---------------- 播放控制 ---------------- */

  function togglePlay(slide) {
    const s = slide || currentSlide();
    if (!s || s.loadState !== 'ready') return;
    const v = s.video;
    if (v.paused) v.play().catch(() => { /* 忽略 */ });
    else v.pause();
  }

  function toggleMute() {
    const s = currentSlide();
    if (!s) return;
    const v = s.video;
    v.muted = !v.muted;
    settings.muted = v.muted;
    if (!v.muted) state.forceMuted = false;
    syncMuteIcon();
    showToast(v.muted ? '已静音' : '已取消静音');
  }

  function toggleDanmaku() {
    settings.danmakuOn = !settings.danmakuOn;
    try { chrome.storage.sync.set({ danmakuOn: settings.danmakuOn }); } catch (e) { /* 忽略 */ }
    applySettings();
    showToast(settings.danmakuOn ? '弹幕已开启' : '弹幕已关闭');
  }

  function toggleFill() {
    settings.fill = settings.fill === 'cover' ? 'contain' : 'cover';
    applySettings();
    try { chrome.storage.sync.set({ fill: settings.fill }); } catch (e) { /* 忽略 */ }
    showToast(settings.fill === 'cover' ? '画面已铺满屏幕' : '画面完整显示');
  }

  function toggleFullscreen() {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => { /* 忽略 */ });
    } else if (host && host.requestFullscreen) {
      host.requestFullscreen().catch(() => { /* 忽略 */ });
    }
  }

  function seekBy(d) {
    const s = currentSlide();
    if (!s) return;
    const v = s.video;
    if (!isFinite(v.duration) || !v.duration) return;
    v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + d));
  }

  /* ---------------- 进度条 ---------------- */

  function updateProgressUI(slide) {
    if (!slide) return;
    const v = slide.video;
    const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : (slide.data ? slide.data.duration : 0);
    const cur = v.currentTime || 0;
    ui.timeCur.textContent = fmtTime(cur);
    ui.timeDur.textContent = fmtTime(dur);
    const ratio = dur ? Math.min(1, cur / dur) : 0;
    if (!seeking) {
      ui.played.style.width = (ratio * 100) + '%';
      ui.knob.style.left = (ratio * 100) + '%';
    }
  }

  function updateBuffered(slide) {
    if (!slide) return;
    const v = slide.video;
    try {
      if (v.buffered.length && isFinite(v.duration) && v.duration) {
        let end = 0;
        for (let i = 0; i < v.buffered.length; i++) end = Math.max(end, v.buffered.end(i));
        ui.buffered.style.width = Math.min(100, end / v.duration * 100) + '%';
      }
    } catch (e) { /* 忽略 */ }
  }

  /* ---------------- 交互事件 ---------------- */

  function onWheel(e) {
    e.preventDefault();
    const now = performance.now();
    if (now - lastWheelTime > 350) wheelArmed = true;
    lastWheelTime = now;
    const d = e.deltaY;
    if (Math.abs(d) < 10) { wheelArmed = true; return; }
    if (state.locked || !wheelArmed) return;
    wheelArmed = false;
    go(d > 0 ? 1 : -1);
  }

  function onTouchStart(e) {
    touchY = e.touches[0].clientY;
    touchX = e.touches[0].clientX;
  }
  function onTouchMove(e) { e.preventDefault(); }
  function onTouchEnd(e) {
    if (touchY == null) return;
    const dy = touchY - e.changedTouches[0].clientY;
    const dx = Math.abs(touchX - e.changedTouches[0].clientX);
    if (Math.abs(dy) > 60 && Math.abs(dy) > dx) go(dy > 0 ? 1 : -1);
    touchY = null;
  }

  function onKey(e) {
    if (!state.active) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const t = e.target;
    if (t && t.closest && t.closest('input,textarea,select,[contenteditable="true"]')) return;
    switch (e.key) {
      case 'ArrowDown':
      case 'PageDown':
        e.preventDefault(); e.stopPropagation(); go(1); break;
      case 'ArrowUp':
      case 'PageUp':
        e.preventDefault(); e.stopPropagation(); go(-1); break;
      case ' ':
        e.preventDefault(); e.stopPropagation(); togglePlay(); break;
      case 'ArrowLeft':
        e.preventDefault(); e.stopPropagation(); seekBy(-5); break;
      case 'ArrowRight':
        e.preventDefault(); e.stopPropagation(); seekBy(5); break;
      case 'j': case 'J':
        seekBy(-10); break;
      case 'l': case 'L':
        seekBy(10); break;
      case 'k': case 'K':
        togglePlay(); break;
      case 'm': case 'M':
        toggleMute(); break;
      case 'b': case 'B':
        toggleDanmaku(); break;
      case 'x': case 'X':
        toggleComments(); break;
      case 'f': case 'F':
        toggleFullscreen(); break;
      case 'c': case 'C':
        toggleFill(); break;
      case 'Escape':
        if (!document.fullscreenElement) exit();
        break;
    }
  }
  window.addEventListener('keydown', onKey, true);

  /* ---------------- 评论面板 ---------------- */

  function fmtAgo(ts) {
    const d = Date.now() / 1000 - (Number(ts) || 0);
    if (d < 60) return '刚刚';
    if (d < 3600) return Math.floor(d / 60) + '分钟前';
    if (d < 86400) return Math.floor(d / 3600) + '小时前';
    if (d < 86400 * 30) return Math.floor(d / 86400) + '天前';
    if (d < 86400 * 365) return Math.floor(d / 86400 / 30) + '个月前';
    return Math.floor(d / 86400 / 365) + '年前';
  }
  function cmtText(s) {
    const d = document.createElement('div');
    d.textContent = String(s == null ? '' : s);
    return d.innerHTML;
  }

  function toggleComments(force) {
    cmt.open = force != null ? force : !cmt.open;
    ui.cmtPanel.classList.toggle('open', cmt.open);
    ui.cmtTab.style.display = cmt.open ? 'none' : '';
    if (cmt.open) cmtSync();
  }

  function cmtSync() {
    if (!cmt.open || !ui.cmtList) return;
    const s = currentSlide();
    const aid = s && s.data ? s.data.aid : 0;
    if (!aid) {
      if (ui.cmtList.textContent.indexOf('等待视频信息') === -1) {
        ui.cmtList.innerHTML = '<div class="cmt-more">等待视频信息…</div>';
      }
      return;
    }
    // 需要加载：视频切换 / 列表为空且未加载 / 加载失败未达重试上限
    if (cmt.aid !== aid || (!cmt.list.length && !cmt.eof && !cmt.loading && cmt.fails < 3)) {
      cmt.aid = aid; cmt.list = []; cmt.next = 0; cmt.count = 0; cmt.eof = false;
      ui.cmtCount.textContent = '';
      ui.cmtList.innerHTML = '<div class="cmt-more">加载中…</div>';
      loadComments();
    }
  }
  // 自愈巡检：面板开着时每 1.5s 检查（切视频跟随/空列表补载/失败重试）
  setInterval(() => { if (cmt.open) cmtSync(); }, 1500);

  async function loadComments() {
    if (!cmt.open || cmt.loading || cmt.eof || !cmt.aid) return;
    cmt.loading = true;
    const url = 'https://api.bilibili.com/x/v2/reply/main?oid=' + cmt.aid +
      '&type=1&mode=3&ps=20&next=' + cmt.next;
    try {
      let j = null;
      // 页面直连（签名 URL）优先，避免后台请求被风控 412
      try { j = await wbiGet(url); }
      catch (e1) { j = await bgApi(url, { wbi: true }); }
      if (j.code !== 0 || !j.data) throw new Error(j.message || ('code ' + j.code));
      cmt.fails = 0;
      const replies = (j.data.top_replies || []).concat(j.data.replies || []);
      cmt.count = (j.data.cursor && j.data.cursor.all_count) || cmt.count || replies.length;
      if (!j.data.replies || !j.data.replies.length) cmt.eof = true;
      cmt.list = cmt.list.concat(replies);
      cmt.next = (j.data.cursor && j.data.cursor.next) || 0;
      renderComments();
    } catch (e) {
      cmt.fails++;
      if (cmt.fails >= 3) cmt.eof = true; // 连续失败停止自动重试
      ui.cmtCount.textContent = '';
      ui.cmtList.innerHTML = '<div class="cmt-more">评论加载失败：' + cmtText((e && e.message) || e) +
        (cmt.eof ? '' : '（将自动重试）') + '</div>';
    }
    cmt.loading = false;
  }

  function renderComments() {
    ui.cmtCount.textContent = cmt.count ? fmtCount(cmt.count) + ' 条' : '';
    const frag = document.createDocumentFragment();
    if (!cmt.list.length) {
      const d = document.createElement('div');
      d.className = 'cmt-more';
      d.textContent = cmt.eof ? '暂无评论' : '加载中…';
      frag.appendChild(d);
    }
    for (const r of cmt.list) {
      const item = document.createElement('div');
      item.className = 'cmt-item';
      const img = document.createElement('img');
      img.src = ((r.member && r.member.avatar) || '').replace(/^http:/, 'https:');
      img.loading = 'lazy';
      const body = document.createElement('div');
      body.className = 'cmt-body';
      const name = document.createElement('div');
      name.className = 'cmt-name';
      name.textContent = (r.member && r.member.uname) || '匿名';
      const text = document.createElement('div');
      text.className = 'cmt-text';
      text.textContent = (r.content && r.content.message) || '';
      const meta = document.createElement('div');
      meta.className = 'cmt-meta';
      meta.innerHTML = '<span>' + fmtAgo(r.ctime) + '</span><span>♥ ' + fmtCount(r.like) + '</span>' +
        (r.rcount ? '<span>' + r.rcount + ' 回复</span>' : '');
      body.appendChild(name); body.appendChild(text); body.appendChild(meta);
      item.appendChild(img); item.appendChild(body);
      frag.appendChild(item);
    }
    if (cmt.list.length && !cmt.eof) {
      const d = document.createElement('div');
      d.className = 'cmt-more';
      d.textContent = cmt.loading ? '加载中…' : '上滑加载更多';
      frag.appendChild(d);
    }
    ui.cmtList.innerHTML = '';
    ui.cmtList.appendChild(frag);
  }

  /* ---------------- 互动（点赞/收藏/投币/分享） ---------------- */

  async function doLike(slide, btn) {
    if (!slide.data) return;
    if (!isLogged()) { showToast('请先登录B站，再回来点赞吧'); return; }
    const liked = btn.classList.contains('on');
    btn.disabled = true;
    try {
      const params = { bvid: slide.bvid, like: liked ? '2' : '1', csrf: getCsrf() };
      let j = null;
      try { j = await directPost('https://api.bilibili.com/x/web-interface/archive/like', params); }
      catch (e1) { j = await bgApi('https://api.bilibili.com/x/web-interface/archive/like', { method: 'POST', body: new URLSearchParams(params).toString() }); }
      if (j.code === 0) {
        btn.classList.toggle('on', !liked);
        slide.data.stat.like += liked ? -1 : 1;
        slide.el.querySelector('.like .rail-count').textContent = fmtCount(slide.data.stat.like);
        showToast(liked ? '已取消点赞' : '点赞成功 (๑•̀ㅂ•́)و✧');
      } else if (j.code === 65006) {
        btn.classList.add('on');
        showToast('已经赞过啦');
      } else {
        showToast('点赞失败：' + (j.message || j.code));
      }
    } catch (e) {
      showToast('点赞失败：' + ((e && e.message) || e));
    }
    btn.disabled = false;
  }

  async function doCoin(slide, btn) {
    if (!slide.data) return;
    if (!isLogged()) { showToast('请先登录B站，再回来投币吧'); return; }
    btn.disabled = true;
    try {
      const params = { bvid: slide.bvid, multiply: '1', select_like: '0', csrf: getCsrf() };
      let j = null;
      try { j = await directPost('https://api.bilibili.com/x/web-interface/coin/add', params); }
      catch (e1) { j = await bgApi('https://api.bilibili.com/x/web-interface/coin/add', { method: 'POST', body: new URLSearchParams(params).toString() }); }
      if (j.code === 0) {
        btn.classList.add('on');
        slide.data.stat.coin += 1;
        slide.el.querySelector('.coin .rail-count').textContent = fmtCount(slide.data.stat.coin);
        showToast('投币成功，感谢对UP主的支持');
      } else {
        showToast('投币失败：' + (j.message || j.code));
      }
    } catch (e) {
      showToast('投币失败：' + ((e && e.message) || e));
    }
    btn.disabled = false;
  }

  async function getMyMid() {
    if (myMid != null) return myMid;
    myMid = parseInt(getCookie('DedeUserID'), 10) || 0;
    if (!myMid) {
      try {
        const j = await directGet('https://api.bilibili.com/x/web-interface/nav');
        myMid = (j.data && j.data.mid) || 0;
      } catch (e) { myMid = 0; }
    }
    return myMid;
  }

  async function doFav(slide, btn) {
    if (!slide.data || !slide.data.aid) { showToast('视频信息加载中，稍后再试'); return; }
    if (!isLogged()) { showToast('请先登录B站后再收藏'); return; }
    btn.disabled = true;
    try {
      const mid = await getMyMid();
      if (!mid) { showToast('未获取到登录信息，请刷新页面重试'); btn.disabled = false; return; }
      // 收藏夹列表（list-all 带 rid/type 时返回默认收藏夹与每夹收藏状态）
      let fid = 0, fname = '默认收藏夹', faved = false;
      try {
        const fl = await directGet('https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=' + mid +
          '&rid=' + slide.data.aid + '&type=2');
        const list = (fl && fl.data && Array.isArray(fl.data)) ? fl.data : [];
        if (list.length) {
          const target = list.find((f) => Number(f.fav_state) === 1) || list[0];
          fid = target.id;
          fname = target.title || fname;
          faved = Number(target.fav_state) === 1;
        }
      } catch (e) { /* 列表失败走兜底 */ }
      if (!fid) fid = mid; // 兜底
      const on = faved || btn.classList.contains('on');
      const p = { rid: String(slide.data.aid), type: '2', csrf: getCsrf() };
      if (on) p.del_media_ids = String(fid); else p.add_media_ids = String(fid);
      let j = null;
      try { j = await directPost('https://api.bilibili.com/x/v3/fav/resource/deal', p); }
      catch (e1) { j = await bgApi('https://api.bilibili.com/x/v3/fav/resource/deal', { method: 'POST', body: new URLSearchParams(p).toString() }); }
      if (j.code === 0) {
        btn.classList.toggle('on', !on);
        slide.data.stat.favorite += on ? -1 : 1;
        slide.el.querySelector('.fav .rail-count').textContent = fmtCount(slide.data.stat.favorite);
        showToast(on ? '已取消收藏（' + fname + '）' : '已收藏到「' + fname + '」');
      } else {
        showToast('收藏失败：' + (j.message || j.code));
      }
    } catch (e) {
      showToast('收藏失败：' + ((e && e.message) || e));
    }
    btn.disabled = false;
  }

  function doShare(slide) {
    const url = 'https://www.bilibili.com/video/' + slide.bvid + '/';
    const done = () => {
      if (slide.data) {
        slide.data.stat.share += 1;
        slide.el.querySelector('.share .rail-count').textContent = fmtCount(slide.data.stat.share);
      }
      showToast('链接已复制，快去分享吧');
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(done).catch(() => fallbackCopy(url, done));
    } else {
      fallbackCopy(url, done);
    }
  }

  function fallbackCopy(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { showToast('复制失败'); }
    ta.remove();
  }

  /* ---------------- 提示 ---------------- */

  function showToast(text, ms) {
    if (!ui.toastEl) return;
    ui.toastEl.textContent = text;
    ui.toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => ui.toastEl.classList.remove('show'), ms || 1800);
  }
  function showSpin(slide, on) {
    if (!slide || !slide.el) return;
    const el = slide.el.querySelector('.spin');
    if (el) el.hidden = !on;
  }
  function showMsg(slide, text, actions) {
    const box = slide.el.querySelector('.center-msg');
    if (!box) return;
    box.querySelector('.msg-text').textContent = text;
    const acts = box.querySelector('.msg-actions');
    acts.innerHTML = '';
    (actions || []).forEach((a) => {
      const b = document.createElement('button');
      b.textContent = a.label;
      if (a.ghost) b.className = 'ghost';
      b.addEventListener('click', () => a.fn());
      acts.appendChild(b);
    });
    box.hidden = false;
  }
  function hideMsg(slide) {
    const box = slide.el.querySelector('.center-msg');
    if (box) box.hidden = true;
  }

  /* ---------------- 进入 / 退出 ---------------- */

  function enter() {
    if (state.active) return;
    const m = location.pathname.match(/\/video\/(BV[0-9A-Za-z]{10})/);
    if (!m) { showToast('请在B站视频页面使用竖刷'); return; }
    const bvid = m[1];
    state.seedPage = Math.max(1, parseInt(new URLSearchParams(location.search).get('p') || '1', 10) || 1);
    buildUI();
    state.active = true;
    state.order = [bvid];
    state.visited = new Set([bvid]);
    state.idx = -1;
    state.slides.clear();
    state.popularPage = 1;
    state.forceMuted = false;
    state.locked = false;
    cmt.open = false;
    prevState.overflowBody = document.body.style.overflow;
    prevState.overflowHtml = document.documentElement.style.overflow;
    prevState.title = document.title;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    try {
      for (const v of document.querySelectorAll('video')) v.pause();
    } catch (e) { /* 忽略 */ }
    setIndex(0);
    if (!localStorage.getItem('bs_hint_v2')) {
      showToast('滚轮或 ↑↓ 切换 · 空格 暂停 · B 弹幕 · 右上角切清晰度 · Esc 退出', 4200);
      localStorage.setItem('bs_hint_v2', '1');
    }
  }

  function exit() {
    if (!state.active) return;
    state.active = false;
    for (const s of state.slides.values()) {
      try { if (s.player) s.player.destroy(); } catch (e) { /* 忽略 */ }
      try { if (s.danmaku) s.danmaku.destroy(); } catch (e) { /* 忽略 */ }
      try { s.video.pause(); } catch (e) { /* 忽略 */ }
    }
    if (document.fullscreenElement) document.exitFullscreen().catch(() => { /* 忽略 */ });
    document.body.style.overflow = prevState.overflowBody;
    document.documentElement.style.overflow = prevState.overflowHtml;
    document.title = prevState.title;
    if (host) { host.remove(); host = null; shadow = null; ui = {}; }
    state.slides.clear();
    state.locked = false;
  }

  function toggle() { state.active ? exit() : enter(); }

  /* ---------------- 消息通道 ---------------- */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg && msg.type === 'toggle') { toggle(); sendResponse({ ok: true, active: state.active }); }
      else if (msg && msg.type === 'query') { sendResponse({ ok: true, active: state.active }); }
    } catch (e) {
      try { sendResponse({ ok: false, error: String(e) }); } catch (e2) { /* 忽略 */ }
    }
  });

  /* TEMP-DIAG（验证后移除）：把关键接口真实响应写进诊断条 */
  setTimeout(async () => {
    try {
      await new Promise((r) => setTimeout(r, 6000));
      const s = state.slides.get(state.order[state.idx]);
      const cid = s ? s.cid : 0;
      const out = ['diag cid=' + cid];
      if (cid) {
        try {
          const su = await wbiSignC('https://api.bilibili.com/x/v2/dm/wbi/web/seg.so?type=1&oid=' + cid +
            '&segment_index=1&dm_img_list=%5B%5D&dm_img_str=base64&dm_cover_img_str=base64' +
            '&dm_img_inter=%7B%22ds%22%3A%5B%5D%2C%22wh%22%3A%5B0%2C0%2C0%5D%2C%22of%22%3A%5B0%2C0%2C0%5D%7D');
          out.push('segurl=' + su.slice(su.indexOf('seg.so')));
          const r = await fetch(su, { credentials: 'include' });
          out.push('segstatus=' + r.status);
          const b = new Uint8Array(await r.arrayBuffer());
          let hx = '';
          for (let i = 0; i < Math.min(16, b.length); i++) hx += b[i].toString(16).padStart(2, '0');
          out.push('seghex=' + hx);
          out.push('seghead=' + new TextDecoder('utf-8').decode(b.slice(0, 90)).replace(/\s+/g, ' '));
        } catch (e) { out.push('segerr=' + shortErr(e)); }
        try {
          const mid = await getMyMid();
          const aid = s && s.data ? s.data.aid : 0;
          const r2 = await fetch('https://api.bilibili.com/x/v3/fav/folder/fav/list?up_mid=' + mid + '&rid=' + aid + '&type=2&ps=30', { credentials: 'include' });
          out.push('favst=' + r2.status);
          const j2 = await r2.json();
          out.push('favcode=' + j2.code + ' folders=' + (j2.data && j2.data.list ? j2.data.list.length : 'na'));
          if (j2.data && j2.data.list && j2.data.list.length) out.push('fid0=' + j2.data.list[0].id + '/' + j2.data.list[0].title);
        } catch (e) { out.push('faverr=' + shortErr(e)); }
      }
      const d = document.createElement('div');
      d.style.cssText = 'position:fixed;left:6px;top:6px;z-index:2147483646;color:#7cfc00;background:rgba(0,0,0,.85);font-size:11px;max-width:560px;word-break:break-all;';
      d.textContent = out.join(' || ');
      document.body.appendChild(d);
    } catch (e) { }
  }, 6000);
})();
