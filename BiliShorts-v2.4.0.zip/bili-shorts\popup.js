'use strict';

const DEFAULTS = { dashQn: 'max', danmakuOn: true, autoNext: true, fill: 'contain' };
const $ = (s) => document.querySelector(s);
const msg = $('#msg');
const toggleBtn = $('#toggle');

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isBiliVideoTab(tab) {
  return !!(tab && tab.url && /^https:\/\/www\.bilibili\.com\/video\//.test(tab.url));
}

async function refreshState() {
  try {
    const tab = await activeTab();
    if (!isBiliVideoTab(tab)) {
      msg.textContent = '提示：请在B站视频页（www.bilibili.com/video/…）中使用';
      return;
    }
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'query' });
    if (res && res.ok && res.active) toggleBtn.textContent = '✕ 关闭竖屏模式';
  } catch (e) {
    /* 内容脚本未注入（页面刚打开未刷新），保持默认按钮文案 */
  }
}

toggleBtn.addEventListener('click', async () => {
  msg.textContent = '';
  try {
    const tab = await activeTab();
    if (!isBiliVideoTab(tab)) {
      msg.textContent = '请先打开一个B站视频页面再使用（www.bilibili.com/video/BV…）';
      return;
    }
    await chrome.tabs.sendMessage(tab.id, { type: 'toggle' });
    window.close();
  } catch (e) {
    msg.textContent = '无法连接页面：请刷新B站页面后重试（刚安装扩展后，已打开的页面需要刷新一次）';
  }
});

chrome.storage.sync.get(DEFAULTS).then((s) => {
  $('#dashQn').value = String(s.dashQn);
  $('#fill').value = s.fill;
  $('#autoNext').checked = !!s.autoNext;
  $('#danmakuOn').checked = !!s.danmakuOn;
}).catch(() => {});

$('#dashQn').addEventListener('change', (e) => {
  const v = e.target.value;
  chrome.storage.sync.set({ dashQn: v === 'max' ? 'max' : Number(v) });
});
$('#fill').addEventListener('change', (e) => chrome.storage.sync.set({ fill: e.target.value }));
$('#autoNext').addEventListener('change', (e) => chrome.storage.sync.set({ autoNext: e.target.checked }));
$('#danmakuOn').addEventListener('change', (e) => chrome.storage.sync.set({ danmakuOn: e.target.checked }));

refreshState();
